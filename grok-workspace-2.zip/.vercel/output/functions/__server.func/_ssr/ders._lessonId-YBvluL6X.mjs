import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, U as require_react, b as Navigate, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as RotateCcw, i as Sparkles, u as Check } from "../_libs/lucide-react.mjs";
import { n as Route } from "./router-D0lPbSJE.mjs";
import { c as lessonById, d as shuffle, f as useProgress, n as cn, p as wordCount, r as foldTr } from "./progress-store-oxWVW0f-.mjs";
import { n as LeafMark, t as AppShell } from "./app-shell-CaDmgJeS.mjs";
import { t as Button } from "./button-9kI4XquE.mjs";
import { n as Textarea, t as ListenButton } from "./textarea-KjCC97k7.mjs";
import { t as Input } from "./input-CulGEXzu.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ders._lessonId-YBvluL6X.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ctx = null;
function context() {
	if (typeof window === "undefined") return null;
	const AudioCtx = window.AudioContext || window.webkitAudioContext;
	if (!AudioCtx) return null;
	ctx ??= new AudioCtx();
	return ctx;
}
function tone(frequency, duration, type, gain = .07) {
	const audio = context();
	if (!audio) return;
	const osc = audio.createOscillator();
	const amp = audio.createGain();
	osc.type = type;
	osc.frequency.value = frequency;
	amp.gain.value = gain;
	amp.gain.exponentialRampToValueAtTime(.001, audio.currentTime + duration);
	osc.connect(amp);
	amp.connect(audio.destination);
	osc.start();
	osc.stop(audio.currentTime + duration);
}
function playCorrect() {
	tone(660, .12, "sine", .06);
	setTimeout(() => tone(880, .16, "sine", .05), 80);
}
function playWrong() {
	tone(220, .18, "triangle", .05);
}
function playComplete() {
	tone(523, .12, "sine", .05);
	setTimeout(() => tone(659, .12, "sine", .05), 90);
	setTimeout(() => tone(784, .2, "sine", .06), 180);
}
function isCorrect(question, answer, ordered) {
	if (question.type === "choice") return answer === question.correctId;
	if (question.type === "spell") return foldTr(answer) === foldTr(question.answer);
	if (question.type === "order") return ordered.length === question.correct.length && ordered.every((item, i) => item === question.correct[i]);
	return wordCount(answer) >= question.minWords;
}
function LessonEngine({ lesson }) {
	const navigate = useNavigate();
	const completeLesson = useProgress((s) => s.completeLesson);
	const [index, setIndex] = (0, import_react.useState)(0);
	const [choice, setChoice] = (0, import_react.useState)(null);
	const [typed, setTyped] = (0, import_react.useState)("");
	const [picked, setPicked] = (0, import_react.useState)([]);
	const [pool, setPool] = (0, import_react.useState)([]);
	const [status, setStatus] = (0, import_react.useState)("idle");
	const [firstTries, setFirstTries] = (0, import_react.useState)(0);
	const [attempts, setAttempts] = (0, import_react.useState)(0);
	const [done, setDone] = (0, import_react.useState)(false);
	const question = lesson.questions[index];
	const seededPool = (0, import_react.useMemo)(() => {
		if (!question || question.type !== "order") return [];
		let tiles = shuffle(question.tiles);
		if (tiles.join("|") === question.correct.join("|")) tiles = shuffle(tiles);
		return tiles;
	}, [question]);
	if (!question) return null;
	const startPool = pool.length || picked.length ? pool : seededPool;
	const progress = (index + (done ? 1 : 0)) / lesson.questions.length * 100;
	const stars = firstTries === lesson.questions.length ? 3 : firstTries >= Math.ceil(lesson.questions.length * .7) ? 2 : 1;
	const leaves = stars + (stars === 3 ? 2 : 0);
	function resetQuestionExtras() {
		setChoice(null);
		setTyped("");
		setPicked([]);
		setPool([]);
		setStatus("idle");
		setAttempts(0);
	}
	function check() {
		if (!question) return;
		if (isCorrect(question, choice ?? typed, picked)) {
			playCorrect();
			setStatus("ok");
			if (attempts === 0) setFirstTries((n) => n + 1);
		} else {
			playWrong();
			setStatus("bad");
			setAttempts((n) => n + 1);
		}
	}
	function next() {
		if (index + 1 >= lesson.questions.length) {
			playComplete();
			completeLesson(lesson.id, stars, leaves);
			setDone(true);
			return;
		}
		setIndex((n) => n + 1);
		resetQuestionExtras();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: lesson.title,
		backTo: `/ada/${lesson.islandId}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-4 h-2 overflow-hidden rounded-full bg-clay",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-full rounded-full bg-leaf transition-[width] duration-300 ease-out",
				style: { width: `${done ? 100 : progress}%` }
			})
		}), done ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "stagger-in paper-sheet rounded-2xl p-6 shadow-border",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/art/mascot.jpg",
					alt: "",
					className: "mx-auto size-28 rounded-xl object-cover"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-center font-display text-3xl",
					children: "Harika iş!"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-center text-ink-soft",
					children: [lesson.subtitle, " tamamlandı."]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 flex justify-center gap-2",
					children: Array.from({ length: stars }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "leaf-pop text-leaf",
						style: { animationDelay: `${i * 80}ms` },
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeafMark, { className: "size-8" })
					}, i))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-center font-display text-lg text-leaf",
					children: [
						"+",
						leaves,
						" yaprak"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 grid gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						onClick: () => navigate({ to: `/ada/${lesson.islandId}` }),
						children: "Adaya dön"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						variant: "paper",
						onClick: () => navigate({ to: "/yaz" }),
						children: "Yazı defterine geç"
					})]
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("rounded-2xl bg-page p-5 shadow-border", status === "bad" && "shake-x"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm font-medium uppercase tracking-wide text-muted",
					children: [
						index + 1,
						" / ",
						lesson.questions.length
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-2 font-display text-2xl",
					children: question.prompt
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListenButton, { text: question.speak ?? question.prompt })
				}),
				question.type === "choice" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 grid gap-3",
					children: question.options.map((option) => {
						const selected = choice === option.id;
						const reveal = status === "ok" && option.id === question.correctId;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								if (status === "ok") return;
								setChoice(option.id);
								setStatus("idle");
							},
							className: cn("min-h-14 rounded-xl px-4 py-3 text-left font-display text-xl shadow-border transition-[transform,background-color] duration-150 active:scale-[0.96]", selected ? "bg-clay" : "bg-paper", reveal && "bg-leaf-soft text-leaf"),
							children: option.label
						}, option.id);
					})
				}),
				question.type === "spell" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: typed,
						onChange: (e) => {
							setTyped(e.target.value);
							setStatus("idle");
						},
						placeholder: "Buraya yaz",
						autoCapitalize: "none",
						autoCorrect: "off",
						spellCheck: false
					})
				}),
				question.type === "order" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-h-16 flex-wrap gap-2 rounded-xl bg-sun/70 p-3",
						children: [picked.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-muted",
							children: "Sıraya koymak için taşlara dokun"
						}), picked.map((tile, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "rounded-md bg-page px-3 py-2 font-display text-lg shadow-border",
							onClick: () => {
								if (status === "ok") return;
								setPicked(picked.filter((_, idx) => idx !== i));
								setPool([...startPool, tile]);
								setStatus("idle");
							},
							children: tile
						}, `${tile}-${i}`))]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: startPool.map((tile, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "rounded-md bg-clay px-3 py-2 font-display text-lg",
							onClick: () => {
								if (status === "ok") return;
								setPool(startPool.filter((_, idx) => idx !== i));
								setPicked([...picked, tile]);
								setStatus("idle");
							},
							children: tile
						}, `${tile}-p-${i}`))
					})]
				}),
				question.type === "write" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 space-y-3",
					children: [
						question.starters && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: question.starters.map((starter) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "rounded-md bg-leaf-soft px-3 py-2 text-sm text-leaf",
								onClick: () => setTyped((prev) => `${prev}${prev ? " " : ""}${starter} `),
								children: starter
							}, starter))
						}),
						question.scaffold ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-3",
							children: question.scaffold.map((box, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mb-1 block text-sm font-medium text-ink-soft",
									children: box.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									className: "paper-ruled min-h-28",
									placeholder: box.placeholder,
									value: typed.split("\n\n")[i] ?? "",
									onChange: (e) => {
										const parts = typed.split("\n\n");
										while (parts.length < question.scaffold.length) parts.push("");
										parts[i] = e.target.value;
										setTyped(parts.join("\n\n"));
										setStatus("idle");
									}
								})]
							}, box.title))
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							className: "paper-ruled min-h-44",
							value: typed,
							placeholder: "Yazmaya başla…",
							onChange: (e) => {
								setTyped(e.target.value);
								setStatus("idle");
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted tabular-nums",
							children: [
								wordCount(typed),
								" kelime · en az ",
								question.minWords
							]
						})
					]
				}),
				status === "ok" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 flex items-center gap-2 font-display text-lg text-leaf",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-5" }), " Bravo, doğru!"]
				}),
				status === "bad" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-terracotta",
					children: question.hint ?? "Bir daha dene, neredeyse oldu."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap gap-3",
					children: [status === "ok" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "lg",
						className: "flex-1",
						onClick: next,
						children: [index + 1 >= lesson.questions.length ? "Bitir" : "Sonraki", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4" })]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						className: "flex-1",
						onClick: check,
						disabled: question.type === "choice" && !choice || question.type === "spell" && !typed.trim() || question.type === "order" && picked.length === 0 || question.type === "write" && !typed.trim(),
						children: "Kontrol et"
					}), status === "bad" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "lg",
						variant: "ghost",
						onClick: () => {
							resetQuestionExtras();
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "Sıfırla"]
					})]
				})
			]
		})]
	});
}
function DersPage() {
	const { lessonId } = Route.useParams();
	const lesson = lessonById(lessonId);
	if (!lesson) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/harita" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LessonEngine, { lesson });
}
//#endregion
export { DersPage as component };

import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, U as require_react, b as Navigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as useProgress } from "./progress-store-oxWVW0f-.mjs";
import { t as Button } from "./button-9kI4XquE.mjs";
import { t as speak } from "./speech-D0AYx3CR.mjs";
import { t as Input } from "./input-CulGEXzu.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-B602nVHg.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var grades = [
	{
		id: 1,
		label: "1. sınıf",
		hint: "Harf ve hece"
	},
	{
		id: 2,
		label: "2. sınıf",
		hint: "Cümle ve kelime"
	},
	{
		id: 3,
		label: "3. sınıf",
		hint: "Hikaye"
	},
	{
		id: 4,
		label: "4. sınıf",
		hint: "Kompozisyon"
	}
];
function Home() {
	const hydrated = useProgress((s) => s.hydrated);
	const onboarded = useProgress((s) => s.onboarded);
	const onboard = useProgress((s) => s.onboard);
	const addListen = useProgress((s) => s.addListen);
	const markHydrated = useProgress((s) => s.markHydrated);
	const [name, setName] = (0, import_react.useState)("");
	const [grade, setGrade] = (0, import_react.useState)(1);
	(0, import_react.useEffect)(() => {
		const finish = () => markHydrated();
		const persistApi = useProgress.persist;
		if (persistApi.hasHydrated()) finish();
		const timeout = window.setTimeout(finish, 600);
		const unsub = persistApi.onFinishHydration(finish);
		return () => {
			window.clearTimeout(timeout);
			unsub();
		};
	}, [markHydrated]);
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "paper-sheet flex min-h-dvh flex-col items-center justify-center gap-4 px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: "/art/mascot.jpg",
			alt: "",
			className: "size-32 rounded-2xl object-cover shadow-border"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-3xl",
			children: "Kalemcan"
		})]
	});
	if (onboarded) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/harita" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "paper-sheet min-h-dvh px-4 py-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex w-full max-w-lg flex-col gap-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "stagger-in text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/art/mascot.jpg",
							alt: "Kalemcan, yaprak şapkalı kalem",
							className: "mx-auto size-40 rounded-2xl object-cover shadow-border"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-5 font-display text-4xl",
							children: "Merhaba, ben Kalemcan"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-lg text-ink-soft",
							children: "MEB’e uygun, oyun gibi bir yazı bahçesi. Harften kompozisyona, birlikte yazalım."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 flex justify-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "paper",
								onClick: () => {
									speak("Merhaba, ben Kalemcan. Birlikte yazmayı öğreneceğiz.");
									addListen();
								},
								children: "Kalemcan’ı dinle"
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mb-2 block font-display text-lg",
						children: "Adın ne?"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: name,
						onChange: (e) => setName(e.target.value),
						placeholder: "Adını yaz",
						maxLength: 24,
						autoComplete: "nickname"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 font-display text-lg",
					children: "Kaçıncı sınıfsın?"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-3",
					children: grades.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setGrade(item.id),
						className: grade === item.id ? "rounded-xl bg-terracotta px-4 py-4 text-left text-page shadow-border" : "rounded-xl bg-page px-4 py-4 text-left shadow-border",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-display text-xl",
							children: item.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: grade === item.id ? "text-sm text-page/80" : "text-sm text-muted",
							children: item.hint
						})]
					}, item.id))
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					onClick: () => {
						onboard(name, grade);
					},
					children: "Bahçeye gir"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-center text-sm text-muted",
					children: "1–4. sınıf Türkçe yazma kazanımları: ses, hece, cümle, hikaye, kompozisyon."
				})
			]
		})
	});
}
//#endregion
export { Home as component };

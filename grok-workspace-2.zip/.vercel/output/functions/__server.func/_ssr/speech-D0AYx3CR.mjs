//#region node_modules/.nitro/vite/services/ssr/assets/speech-D0AYx3CR.js
function speak(text) {
	if (typeof window === "undefined" || !window.speechSynthesis) return false;
	const trimmed = text.trim();
	if (!trimmed) return false;
	window.speechSynthesis.cancel();
	const utterance = new SpeechSynthesisUtterance(trimmed);
	utterance.lang = "tr-TR";
	utterance.rate = .88;
	utterance.pitch = 1.05;
	const voices = window.speechSynthesis.getVoices();
	const turkish = voices.find((voice) => voice.lang.toLowerCase().startsWith("tr")) ?? voices.find((voice) => /turk/i.test(voice.name));
	if (turkish) utterance.voice = turkish;
	window.speechSynthesis.speak(utterance);
	return true;
}
//#endregion
export { speak as t };

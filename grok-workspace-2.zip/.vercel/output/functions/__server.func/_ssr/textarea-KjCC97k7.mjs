import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Volume2 } from "../_libs/lucide-react.mjs";
import { f as useProgress, n as cn } from "./progress-store-oxWVW0f-.mjs";
import { t as Button } from "./button-9kI4XquE.mjs";
import { t as speak } from "./speech-D0AYx3CR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/textarea-KjCC97k7.js
var import_jsx_runtime = require_jsx_runtime();
function ListenButton({ text, label = "Dinle" }) {
	const addListen = useProgress((s) => s.addListen);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		type: "button",
		variant: "paper",
		size: "sm",
		onClick: () => {
			if (speak(text)) addListen();
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-4" }), label]
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("min-h-40 w-full rounded-xl bg-page px-4 py-3 text-base text-ink shadow-border", "placeholder:text-muted focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-terracotta", className),
		...props
	});
}
//#endregion
export { Textarea as n, ListenButton as t };

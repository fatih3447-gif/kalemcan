import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as cn } from "./progress-store-oxWVW0f-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/input-CulGEXzu.js
var import_jsx_runtime = require_jsx_runtime();
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("h-12 w-full rounded-lg bg-page px-4 text-base text-ink shadow-border", "placeholder:text-muted focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-terracotta", className),
		...props
	});
}
//#endregion
export { Input as t };

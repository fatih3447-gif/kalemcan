import { C as require_jsx_runtime, S as useRouter, f as useRouterState, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { l as ChevronLeft, n as Trophy, o as PencilLine, s as Map } from "../_libs/lucide-react.mjs";
import { f as useProgress, n as cn } from "./progress-store-oxWVW0f-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/app-shell-CaDmgJeS.js
var import_jsx_runtime = require_jsx_runtime();
function LeafMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 24 24",
		className: cn("size-5", className),
		"aria-hidden": true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			fill: "currentColor",
			d: "M19.6 4.4c-4.2-.2-9.2 1.6-12 5.3-2.6 3.4-3 7.6-1.4 10.1 2.5 2.4 6.8 1.8 10.1-1.4 3.7-2.8 5.5-7.8 5.3-12-.7 2.2-2.3 4-4.4 4.8 1.4-3.1.7-6.3-1.6-8.2 2.2.4 4 1.6 5 3.4.2-1 .2-1.4-1-2z"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "1.4",
			strokeLinecap: "round",
			d: "M8 20c3.4-3.6 6-8.4 7.4-14",
			opacity: ".55"
		})]
	});
}
var tabs = [
	{
		to: "/harita",
		label: "Bahçe",
		icon: Map
	},
	{
		to: "/yaz",
		label: "Yaz",
		icon: PencilLine
	},
	{
		to: "/rozetler",
		label: "Rozetler",
		icon: Trophy
	}
];
function AppShell({ children, title, backTo }) {
	const router = useRouter();
	const name = useProgress((s) => s.name);
	const leaves = useProgress((s) => s.leaves);
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "paper-sheet min-h-dvh",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-20 border-b border-line bg-page/90 px-4 py-3 backdrop-blur-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-3xl items-center gap-3",
					children: [
						backTo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => router.history.push(backTo),
							className: "inline-flex size-11 items-center justify-center rounded-lg text-ink-soft shadow-border",
							"aria-label": "Geri",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/harita",
							className: "flex min-w-0 items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/art/mascot.jpg",
								alt: "",
								className: "size-11 rounded-lg object-cover"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-lg leading-none text-ink",
									children: "Kalemcan"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-sm text-muted",
									children: name || "Minik yazar"
								})]
							})]
						}),
						title ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "min-w-0 flex-1 truncate font-display text-xl",
							children: title
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "flex-1" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "inline-flex h-11 items-center gap-1.5 rounded-lg bg-leaf-soft px-3 text-leaf tabular-nums",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeafMark, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display font-medium",
								children: leaves
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "mx-auto w-full max-w-3xl px-4 pb-28 pt-5",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-20 border-t border-line bg-page/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto grid max-w-3xl grid-cols-3",
					children: tabs.map((tab) => {
						const active = pathname === tab.to || pathname.startsWith(`${tab.to}/`);
						const Icon = tab.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: tab.to,
							className: cn("flex min-h-16 flex-col items-center justify-center gap-1 text-sm", active ? "text-terracotta" : "text-muted"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" }), tab.label]
						}, tab.to);
					})
				})
			})
		]
	});
}
//#endregion
export { LeafMark as n, AppShell as t };

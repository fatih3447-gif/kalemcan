import { C as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as islandProgress, f as useProgress, o as islands, u as recommendedIslandIds } from "./progress-store-oxWVW0f-.mjs";
import { t as AppShell } from "./app-shell-CaDmgJeS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/harita-C_q6fA99.js
var import_jsx_runtime = require_jsx_runtime();
function HaritaPage() {
	const name = useProgress((s) => s.name);
	const grade = useProgress((s) => s.grade);
	const stars = useProgress((s) => s.stars);
	const recommended = recommendedIslandIds(grade);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stagger-in",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium uppercase tracking-wide text-leaf",
				children: "Yazı bahçesi"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 font-display text-3xl",
				children: name ? `${name}, bugün nereye?` : "Bugün nereye?"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 max-w-prose text-ink-soft",
				children: [grade, ". sınıf için önerilen adalar yaprakla işaretli. İstediğin adaya girebilirsin."]
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
		className: "relative mt-8 space-y-5 before:absolute before:bottom-8 before:left-7 before:top-8 before:w-px before:bg-line",
		children: islands.map((island, i) => {
			const { done, total } = islandProgress(island.id, stars);
			const isRec = recommended.includes(island.id);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "relative pl-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/ada/$islandId",
						params: { islandId: island.id },
						className: "flex gap-4 rounded-2xl bg-page p-3 shadow-border transition-[transform,box-shadow] duration-150 hover:shadow-border-hover active:scale-[0.99]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: island.image,
							alt: "",
							className: "size-24 shrink-0 rounded-xl object-cover sm:size-28"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 py-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "font-display text-xl",
										children: island.title
									}), isRec && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "rounded-md bg-leaf-soft px-2 py-0.5 text-xs font-medium text-leaf",
										children: "Sana uygun"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-ink-soft",
									children: island.subtitle
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 text-sm tabular-nums text-muted",
									children: [
										done,
										"/",
										total,
										" ders"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-2 h-1.5 overflow-hidden rounded-full bg-clay",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-full rounded-full bg-leaf",
										style: { width: `${total ? done / total * 100 : 0}%` }
									})
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute left-0 top-1/2 hidden size-3 -translate-x-[19px] -translate-y-1/2 rounded-full bg-terracotta sm:block" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "sr-only",
						children: ["Adım ", i + 1]
					})
				]
			}, island.id);
		})
	})] });
}
//#endregion
export { HaritaPage as component };

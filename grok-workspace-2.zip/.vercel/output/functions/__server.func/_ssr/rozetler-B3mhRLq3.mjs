import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as useProgress, n as cn, t as badges } from "./progress-store-oxWVW0f-.mjs";
import { n as LeafMark, t as AppShell } from "./app-shell-CaDmgJeS.mjs";
import { t as Button } from "./button-9kI4XquE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/rozetler-B3mhRLq3.js
var import_jsx_runtime = require_jsx_runtime();
function RozetlerPage() {
	const earned = useProgress((s) => s.earnedBadges);
	const leaves = useProgress((s) => s.leaves);
	const reset = useProgress((s) => s.reset);
	const name = useProgress((s) => s.name);
	const grade = useProgress((s) => s.grade);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "Rozetler",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl bg-page p-5 shadow-border",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Sertifika"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-1 font-display text-2xl",
						children: name || "Minik yazar"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-ink-soft",
						children: [
							grade,
							". sınıf yazı bahçesinde ",
							leaves,
							" yaprak topladı."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex items-center gap-2 text-leaf",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeafMark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-display tabular-nums",
							children: [
								earned.length,
								" / ",
								badges.length,
								" rozet"
							]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-6 grid grid-cols-1 gap-3 sm:grid-cols-2",
				children: badges.map((badge) => {
					const on = earned.includes(badge.id);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: cn("rounded-2xl p-4 shadow-border", on ? "bg-leaf-soft" : "bg-page opacity-70"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: on ? "text-leaf" : "text-muted",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeafMark, { className: "size-6" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-2 font-display text-lg",
								children: badge.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-ink-soft",
								children: badge.hint
							})
						]
					}, badge.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: () => {
						if (window.confirm("Bahçeyi baştan mı açalım? İlerleme silinir.")) reset();
					},
					children: "Bahçeyi sıfırla"
				})
			})
		]
	});
}
//#endregion
export { RozetlerPage as component };

import { C as require_jsx_runtime, b as Navigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as Route$1 } from "./router-D0lPbSJE.mjs";
import { f as useProgress, i as islandById, l as lessonsForIsland } from "./progress-store-oxWVW0f-.mjs";
import { n as LeafMark, t as AppShell } from "./app-shell-CaDmgJeS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ada._islandId-qOygd-_U.js
var import_jsx_runtime = require_jsx_runtime();
function IslandPage() {
	const { islandId } = Route$1.useParams();
	const island = islandById(islandId);
	const stars = useProgress((s) => s.stars);
	if (!island) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/harita" });
	const list = lessonsForIsland(island.id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: island.title,
		backTo: "/harita",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: island.image,
				alt: "",
				className: "h-40 w-full rounded-2xl object-cover shadow-border"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-ink-soft",
				children: island.subtitle
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: island.meb
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-6 space-y-3",
				children: list.map((lesson, i) => {
					const score = stars[lesson.id] ?? 0;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/ders/$lessonId",
						params: { lessonId: lesson.id },
						className: "flex items-center gap-4 rounded-2xl bg-page p-4 shadow-border",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex size-12 items-center justify-center rounded-lg bg-clay font-display text-xl",
								children: i + 1
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-lg",
									children: lesson.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: lesson.subtitle
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex gap-0.5 text-leaf",
								children: Array.from({ length: 3 }).map((_, n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeafMark, { className: n < score ? "size-4" : "size-4 opacity-25" }, n))
							})
						]
					}) }, lesson.id);
				})
			})
		]
	});
}
//#endregion
export { IslandPage as component };

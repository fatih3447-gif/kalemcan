import { i as string, n as number, r as object } from "../_libs/zod.mjs";
import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ai-review-mikHstlr.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var Input = object({
	title: string().max(120),
	text: string().min(1).max(4e3),
	grade: number().int().min(1).max(4),
	kind: string().max(40)
});
var reviewWriting_createServerFn_handler = createServerRpc({
	id: "4ca1b213e42db484c87738797c12c4f5b56717bd89744e25d59b8d7052c98d31",
	name: "reviewWriting",
	filename: "src/lib/ai-review.ts"
}, (opts) => reviewWriting.__executeServer(opts));
var reviewWriting = createServerFn({ method: "POST" }).validator((input) => Input.parse(input)).handler(reviewWriting_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "Öğretmen şu anda dinleniyor."
	};
	const res = await fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify({
			model: "grok-4.5",
			temperature: .4,
			max_tokens: 360,
			response_format: { type: "json_object" },
			messages: [{
				role: "system",
				content: "Sen Turkiye MEB 1-4. sinif Turkce yazma ogretmenisin. Cocuklara nazik, somut ve kisa geri bildirim verirsin. Asla kucumseme, alay etme veya sert olma. Once ov, sonra en fazla 2 oneri ver. Cocugun metnini bastan yazma. JSON uret: {\"praise\":\"...\",\"tips\":[\"...\"],\"stars\":1|2|3,\"nextStep\":\"...\"}. Turkce yaz. Yasina uygun dil kullan."
			}, {
				role: "user",
				content: `Sinif: ${data.grade}. Tur: ${data.kind}. Baslik: ${data.title}\n\nYazi:\n${data.text}`
			}]
		})
	});
	if (!res.ok) return {
		ok: false,
		error: "Öğretmen şu anda yanıt veremedi."
	};
	const raw = (await res.json()).choices?.[0]?.message?.content ?? "";
	try {
		const parsed = JSON.parse(raw);
		const stars = Math.min(3, Math.max(1, Number(parsed.stars) || 2));
		return {
			ok: true,
			praise: parsed.praise?.slice(0, 400) || "Çok emek vermişsin, bravo.",
			tips: (parsed.tips ?? []).slice(0, 2).map((tip) => String(tip).slice(0, 220)),
			stars,
			nextStep: parsed.nextStep?.slice(0, 220) || "Bir sonraki yazıda bir örnek daha ekle."
		};
	} catch {
		return {
			ok: false,
			error: "Öğretmenin notu okunamadı."
		};
	}
});
//#endregion
export { reviewWriting_createServerFn_handler };

import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, U as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as string, n as number, r as object } from "../_libs/zod.mjs";
import { c as LoaderCircle, d as BookMarked } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { f as useProgress, m as writingPrompts, n as cn, p as wordCount, s as kindLabels } from "./progress-store-oxWVW0f-.mjs";
import { n as LeafMark, t as AppShell } from "./app-shell-CaDmgJeS.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { t as Button } from "./button-9kI4XquE.mjs";
import { n as Textarea, t as ListenButton } from "./textarea-KjCC97k7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/yaz-CEeNd3pB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var Input = object({
	title: string().max(120),
	text: string().min(1).max(4e3),
	grade: number().int().min(1).max(4),
	kind: string().max(40)
});
var reviewWriting = createServerFn({ method: "POST" }).validator((input) => Input.parse(input)).handler(createSsrRpc("4ca1b213e42db484c87738797c12c4f5b56717bd89744e25d59b8d7052c98d31"));
function joinScaffold(parts) {
	return parts.map((part) => part.trim()).filter(Boolean).join("\n\n");
}
function localTips(text, minWords) {
	const tips = [];
	const folded = text.trim();
	if (wordCount(folded) < minWords) tips.push(`Biraz daha yaz: en az ${minWords} kelime olsun.`);
	if (folded && folded[0] !== folded[0]?.toLocaleUpperCase("tr-TR")) tips.push("Cümleye büyük harfle başla.");
	if (folded && !/[.!?…]$/.test(folded)) tips.push("Cümleyi nokta, soru veya ünlem ile bitir.");
	if (!tips.length) tips.push("Bir örnek veya duygu cümlesi ekleyerek yazını daha canlı yapabilirsin.");
	return tips.slice(0, 2);
}
function WriterStudio() {
	const grade = useProgress((s) => s.grade);
	const saveWriting = useProgress((s) => s.saveWriting);
	const updateWritingFeedback = useProgress((s) => s.updateWritingFeedback);
	const bumpReview = useProgress((s) => s.bumpReview);
	const writings = useProgress((s) => s.writings);
	const [tab, setTab] = (0, import_react.useState)("yeni");
	const prompts = (0, import_react.useMemo)(() => writingPrompts.filter((prompt) => prompt.grades.includes(grade) || grade >= 3), [grade]);
	const [selectedId, setSelectedId] = (0, import_react.useState)(prompts[0]?.id ?? writingPrompts[0].id);
	const prompt = writingPrompts.find((item) => item.id === selectedId) ?? writingPrompts[0];
	const [parts, setParts] = (0, import_react.useState)(() => prompt.scaffold.map(() => ""));
	const [reviewing, setReviewing] = (0, import_react.useState)(false);
	const [lastFeedback, setLastFeedback] = (0, import_react.useState)(null);
	function switchPrompt(next) {
		setSelectedId(next.id);
		setParts(next.scaffold.map(() => ""));
		setLastFeedback(null);
	}
	const body = joinScaffold(parts);
	const minWords = grade <= 2 ? 12 : 28;
	async function onSave(withTeacher) {
		if (wordCount(body) < 4) {
			toast("Birkaç cümle daha yaz, sonra kaydedelim.");
			return;
		}
		const id = saveWriting({
			title: prompt.title,
			body,
			kind: prompt.kind
		});
		toast("Defterine kaydedildi.");
		if (!withTeacher) return;
		if (!bumpReview()) {
			toast("Öğretmen bugün çok yoruldu. Yarın yeniden bakabilir.");
			return;
		}
		setReviewing(true);
		try {
			const result = await reviewWriting({ data: {
				title: prompt.title,
				text: body.slice(0, 4e3),
				grade,
				kind: prompt.kind
			} });
			if (result.ok) {
				updateWritingFeedback(id, result);
				setLastFeedback(result);
				toast("Öğretmen notunu bıraktı.");
			} else {
				const fallback = {
					praise: "Emek verdiğin her cümle değerli. Yazmaya devam!",
					tips: localTips(body, minWords),
					stars: wordCount(body) >= minWords ? 2 : 1,
					nextStep: "Yarına bir cümle daha ekle."
				};
				updateWritingFeedback(id, fallback);
				setLastFeedback(fallback);
				toast(result.error);
			}
		} catch {
			toast("Öğretmen şu anda ulaşılamadı.");
		} finally {
			setReviewing(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-5 grid grid-cols-2 rounded-xl bg-clay p-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: cn("h-11 rounded-lg font-display", tab === "yeni" ? "bg-page text-ink shadow-border" : "text-ink-soft"),
			onClick: () => setTab("yeni"),
			children: "Yeni yazı"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: cn("h-11 rounded-lg font-display", tab === "defter" ? "bg-page text-ink shadow-border" : "text-ink-soft"),
			onClick: () => setTab("defter"),
			children: "Defterim"
		})]
	}), tab === "yeni" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 overflow-x-auto pb-1",
				children: prompts.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => switchPrompt(item),
					className: cn("shrink-0 rounded-lg px-3 py-2 text-sm shadow-border", item.id === prompt.id ? "bg-terracotta text-page" : "bg-page text-ink-soft"),
					children: item.title
				}, item.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl bg-page p-5 shadow-border",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-leaf",
						children: kindLabels[prompt.kind]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-1 font-display text-2xl",
						children: prompt.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-ink-soft",
						children: prompt.blurb
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "MEB: giriş–gelişme–sonuç, konu ve ana fikir."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: prompt.starters.map((starter) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "rounded-md bg-leaf-soft px-3 py-2 text-sm text-leaf",
							onClick: () => {
								const next = [...parts];
								next[0] = `${next[0] ? `${next[0]} ` : ""}${starter} `;
								setParts(next);
							},
							children: [starter, "…"]
						}, starter))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 space-y-4",
						children: prompt.scaffold.map((box, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mb-1 block font-display text-lg",
								children: box.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								className: "paper-ruled min-h-28",
								placeholder: box.placeholder,
								value: parts[i] ?? "",
								onChange: (e) => {
									const next = [...parts];
									next[i] = e.target.value;
									setParts(next);
								}
							})]
						}, box.title))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-sm text-muted tabular-nums",
						children: [wordCount(body), " kelime"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListenButton, {
								text: body || prompt.title,
								label: "Sesli oku"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "paper",
								onClick: () => onSave(false),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookMarked, { className: "size-4" }), "Deftere koy"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: () => onSave(true),
								disabled: reviewing,
								children: [reviewing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeafMark, { className: "size-4" }), "Öğretmene göster"]
							})
						]
					})
				]
			}),
			lastFeedback && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl bg-leaf-soft p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex gap-1 text-leaf",
						children: Array.from({ length: lastFeedback.stars }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeafMark, {}, i))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-display text-xl",
						children: lastFeedback.praise
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 list-disc space-y-1 pl-5 text-ink-soft",
						children: lastFeedback.tips.map((tip) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: tip }, tip))
					}),
					lastFeedback.nextStep && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-leaf",
						children: lastFeedback.nextStep
					})
				]
			})
		]
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-3",
		children: writings.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-2xl bg-page p-6 text-center shadow-border",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-xl",
				children: "Defterin henüz boş"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-ink-soft",
				children: "İlk yazını yaz, buraya düşsün."
			})]
		}) : writings.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "rounded-2xl bg-page p-5 shadow-border",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: kindLabels[entry.kind] ?? entry.kind
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-xl",
					children: entry.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 whitespace-pre-wrap text-ink-soft",
					children: entry.body
				}),
				entry.feedback && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-leaf",
					children: entry.feedback.praise
				})
			]
		}, entry.id))
	})] });
}
function YazPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "Yazı defteri",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-5 text-ink-soft",
			children: "Konu seç, üç bölümle yaz, dilersen öğretmene göster. Mektup, günlük, hikaye ve kompozisyon MEB yazma türlerine göre hazırlandı."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WriterStudio, {})]
	});
}
//#endregion
export { YazPage as component };

//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BgVuBprx.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/harita",
			"/rozetler",
			"/yaz",
			"/ada/$islandId",
			"/ders/$lessonId"
		],
		preloads: [
			"/assets/index-Bvoy5pNa.js",
			"/assets/useRouter-80ermfqe.js",
			"/assets/createLucideIcon-_wMNhrPO.js",
			"/assets/preload-helper-DWUSMfiH.js",
			"/assets/redirect-BGp3mkLZ.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Bvoy5pNa.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CPmek7EA.js",
			"/assets/useNavigate-C31LACoW.js",
			"/assets/progress-store-1j5zOU4P.js",
			"/assets/button-ClFVjMJU.js",
			"/assets/speech-DqcmoUJu.js",
			"/assets/input-CQ1ixfR0.js"
		]
	},
	"/harita": {
		filePath: "/workspace/src/routes/harita.tsx",
		children: void 0,
		preloads: [
			"/assets/harita-DtViI6kn.js",
			"/assets/app-shell-DiAF3u4t.js",
			"/assets/progress-store-1j5zOU4P.js"
		]
	},
	"/rozetler": {
		filePath: "/workspace/src/routes/rozetler.tsx",
		children: void 0,
		preloads: [
			"/assets/rozetler-MkxQ_EAa.js",
			"/assets/app-shell-DiAF3u4t.js",
			"/assets/progress-store-1j5zOU4P.js",
			"/assets/button-ClFVjMJU.js"
		]
	},
	"/yaz": {
		filePath: "/workspace/src/routes/yaz.tsx",
		children: void 0,
		preloads: [
			"/assets/yaz-BZLsCoDR.js",
			"/assets/app-shell-DiAF3u4t.js",
			"/assets/textarea-A6-GiJG3.js",
			"/assets/progress-store-1j5zOU4P.js",
			"/assets/button-ClFVjMJU.js"
		]
	},
	"/ada/$islandId": {
		filePath: "/workspace/src/routes/ada.$islandId.tsx",
		children: void 0,
		preloads: [
			"/assets/ada._islandId-RZbxhB5r.js",
			"/assets/useNavigate-C31LACoW.js",
			"/assets/app-shell-DiAF3u4t.js",
			"/assets/progress-store-1j5zOU4P.js"
		]
	},
	"/ders/$lessonId": {
		filePath: "/workspace/src/routes/ders.$lessonId.tsx",
		children: void 0,
		preloads: [
			"/assets/ders._lessonId-DKtdvMzI.js",
			"/assets/useNavigate-C31LACoW.js",
			"/assets/app-shell-DiAF3u4t.js",
			"/assets/textarea-A6-GiJG3.js",
			"/assets/progress-store-1j5zOU4P.js",
			"/assets/button-ClFVjMJU.js",
			"/assets/input-CQ1ixfR0.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };

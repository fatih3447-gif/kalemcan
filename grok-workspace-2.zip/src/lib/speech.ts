export function speak(text: string) {
  if (typeof window === "undefined" || !window.speechSynthesis) return false;
  const trimmed = text.trim();
  if (!trimmed) return false;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(trimmed);
  utterance.lang = "tr-TR";
  utterance.rate = 0.88;
  utterance.pitch = 1.05;
  const voices = window.speechSynthesis.getVoices();
  const turkish =
    voices.find((voice) => voice.lang.toLowerCase().startsWith("tr")) ??
    voices.find((voice) => /turk/i.test(voice.name));
  if (turkish) utterance.voice = turkish;
  window.speechSynthesis.speak(utterance);
  return true;
}

export function stopSpeech() {
  if (typeof window === "undefined" || !window.speechSynthesis) return;
  window.speechSynthesis.cancel();
}

let ctx: AudioContext | null = null;

function context() {
  if (typeof window === "undefined") return null;
  const AudioCtx =
    window.AudioContext ||
    (window as Window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!AudioCtx) return null;
  ctx ??= new AudioCtx();
  return ctx;
}

function tone(frequency: number, duration: number, type: OscillatorType, gain = 0.07) {
  const audio = context();
  if (!audio) return;
  const osc = audio.createOscillator();
  const amp = audio.createGain();
  osc.type = type;
  osc.frequency.value = frequency;
  amp.gain.value = gain;
  amp.gain.exponentialRampToValueAtTime(0.001, audio.currentTime + duration);
  osc.connect(amp);
  amp.connect(audio.destination);
  osc.start();
  osc.stop(audio.currentTime + duration);
}

export function playCorrect() {
  tone(660, 0.12, "sine", 0.06);
  setTimeout(() => tone(880, 0.16, "sine", 0.05), 80);
}

export function playWrong() {
  tone(220, 0.18, "triangle", 0.05);
}

export function playComplete() {
  tone(523, 0.12, "sine", 0.05);
  setTimeout(() => tone(659, 0.12, "sine", 0.05), 90);
  setTimeout(() => tone(784, 0.2, "sine", 0.06), 180);
}

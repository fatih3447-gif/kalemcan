import { create } from "zustand";
import { persist } from "zustand/middleware";
import {
  badges,
  islands,
  lessons,
  lessonsForIsland,
  type Grade,
  type IslandId,
} from "@/lib/curriculum";
import { uid } from "@/lib/utils";

export type WritingEntry = {
  id: string;
  title: string;
  body: string;
  kind: string;
  createdAt: number;
  feedback?: {
    praise: string;
    tips: string[];
    stars: number;
    nextStep?: string;
  };
};

type ProgressState = {
  hydrated: boolean;
  onboarded: boolean;
  name: string;
  grade: Grade;
  leaves: number;
  stars: Record<string, number>;
  listenCount: number;
  writings: WritingEntry[];
  earnedBadges: string[];
  reviews: { date: string; count: number };
  markHydrated: () => void;
  onboard: (name: string, grade: Grade) => void;
  setGrade: (grade: Grade) => void;
  addListen: () => void;
  completeLesson: (lessonId: string, starCount: number, leafGain: number) => void;
  saveWriting: (entry: Omit<WritingEntry, "id" | "createdAt">) => string;
  updateWritingFeedback: (id: string, feedback: WritingEntry["feedback"]) => void;
  bumpReview: () => boolean;
  reset: () => void;
};

const today = () => new Date().toISOString().slice(0, 10);

function collectBadges(state: {
  stars: Record<string, number>;
  leaves: number;
  listenCount: number;
  writings: WritingEntry[];
  earnedBadges: string[];
}) {
  const earned = new Set(state.earnedBadges);
  const completed = (islandId: IslandId) => {
    const islandLessons = lessonsForIsland(islandId);
    return islandLessons.every((lesson) => (state.stars[lesson.id] ?? 0) > 0);
  };

  if (Object.values(state.stars).some((value) => value > 0)) earned.add("ilk-yaprak");
  if (completed("harf")) earned.add("harf-bahcivan");
  if (completed("hece")) earned.add("hececi");
  if (completed("kelime")) earned.add("kelime-avcisi");
  if (completed("cumle")) earned.add("cumle-usta");
  if (completed("hikaye")) earned.add("anlatici");
  if (lessonsForIsland("kompozisyon").some((lesson) => (state.stars[lesson.id] ?? 0) > 0)) {
    earned.add("yazar");
  }
  if (state.writings.length >= 3) earned.add("defter");
  if (state.listenCount >= 10) earned.add("dinleyici");
  if (state.leaves >= 20) earned.add("yaprak-20");

  return [...earned];
}

export const useProgress = create<ProgressState>()(
  persist(
    (set, get) => ({
      hydrated: false,
      onboarded: false,
      name: "",
      grade: 1,
      leaves: 0,
      stars: {},
      listenCount: 0,
      writings: [],
      earnedBadges: [],
      reviews: { date: today(), count: 0 },
      markHydrated: () => set({ hydrated: true }),
      onboard: (name, grade) =>
        set({
          onboarded: true,
          name: name.trim() || "Minik yazar",
          grade,
        }),
      setGrade: (grade) => set({ grade }),
      addListen: () => {
        const listenCount = get().listenCount + 1;
        set({
          listenCount,
          earnedBadges: collectBadges({ ...get(), listenCount }),
        });
      },
      completeLesson: (lessonId, starCount, leafGain) => {
        const prev = get().stars[lessonId] ?? 0;
        const nextStars = Math.max(prev, starCount);
        const stars = { ...get().stars, [lessonId]: nextStars };
        const leaves = get().leaves + (nextStars > prev ? leafGain : 1);
        const earnedBadges = collectBadges({ ...get(), stars, leaves });
        set({ stars, leaves, earnedBadges });
      },
      saveWriting: (entry) => {
        const id = uid();
        const writings = [
          { ...entry, id, createdAt: Date.now() },
          ...get().writings,
        ].slice(0, 40);
        set({
          writings,
          earnedBadges: collectBadges({ ...get(), writings }),
        });
        return id;
      },
      updateWritingFeedback: (id, feedback) =>
        set({
          writings: get().writings.map((item) =>
            item.id === id ? { ...item, feedback } : item,
          ),
        }),
      bumpReview: () => {
        const current = get().reviews;
        const date = today();
        const count = current.date === date ? current.count : 0;
        if (count >= 8) return false;
        set({ reviews: { date, count: count + 1 } });
        return true;
      },
      reset: () =>
        set({
          onboarded: false,
          name: "",
          grade: 1,
          leaves: 0,
          stars: {},
          listenCount: 0,
          writings: [],
          earnedBadges: [],
          reviews: { date: today(), count: 0 },
        }),
    }),
    {
      name: "kalemcan-progress",
      partialize: (state) => ({
        onboarded: state.onboarded,
        name: state.name,
        grade: state.grade,
        leaves: state.leaves,
        stars: state.stars,
        listenCount: state.listenCount,
        writings: state.writings,
        earnedBadges: state.earnedBadges,
        reviews: state.reviews,
      }),
      onRehydrateStorage: () => () => {
        useProgress.setState({ hydrated: true });
      },
    },
  ),
);

export function islandProgress(islandId: IslandId, stars: Record<string, number>) {
  const islandLessons = lessonsForIsland(islandId);
  const done = islandLessons.filter((lesson) => (stars[lesson.id] ?? 0) > 0).length;
  return { done, total: islandLessons.length };
}

export function recommendedIslandIds(grade: Grade): IslandId[] {
  if (grade === 1) return ["harf", "hece", "kelime"];
  if (grade === 2) return ["hece", "kelime", "cumle", "hikaye"];
  if (grade === 3) return ["kelime", "cumle", "hikaye", "kompozisyon"];
  return ["cumle", "hikaye", "kompozisyon"];
}

export { badges, islands, lessons };

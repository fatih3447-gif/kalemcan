export type Grade = 1 | 2 | 3 | 4;
export type IslandId =
  | "harf"
  | "hece"
  | "kelime"
  | "cumle"
  | "hikaye"
  | "kompozisyon";

export type ChoiceQ = {
  type: "choice";
  id: string;
  prompt: string;
  speak?: string;
  hint?: string;
  options: { id: string; label: string }[];
  correctId: string;
};

export type OrderQ = {
  type: "order";
  id: string;
  prompt: string;
  speak?: string;
  hint?: string;
  tiles: string[];
  correct: string[];
};

export type SpellQ = {
  type: "spell";
  id: string;
  prompt: string;
  speak: string;
  hint?: string;
  answer: string;
};

export type WriteQ = {
  type: "write";
  id: string;
  prompt: string;
  speak?: string;
  hint?: string;
  minWords: number;
  starters?: string[];
  scaffold?: { title: string; placeholder: string }[];
};

export type Question = ChoiceQ | OrderQ | SpellQ | WriteQ;

export type Lesson = {
  id: string;
  islandId: IslandId;
  title: string;
  subtitle: string;
  grades: Grade[];
  questions: Question[];
};

export type Island = {
  id: IslandId;
  title: string;
  subtitle: string;
  image: string;
  grades: Grade[];
  meb: string;
};

export type WritingPrompt = {
  id: string;
  kind: "hikaye" | "betimleme" | "mektup" | "gunluk" | "kompozisyon" | "davetiye";
  title: string;
  blurb: string;
  grades: Grade[];
  starters: string[];
  scaffold: { title: string; placeholder: string }[];
};

export const islands: Island[] = [
  {
    id: "harf",
    title: "Harf Bahçesi",
    subtitle: "Sesleri tanı, harfleri seç",
    image: "/art/island-harf.jpg",
    grades: [1],
    meb: "1. sınıf ses temelli cümle yöntemi: ses-harf eşleştirme",
  },
  {
    id: "hece",
    title: "Hece Deresi",
    subtitle: "Heceleri birleştir",
    image: "/art/island-hece.jpg",
    grades: [1, 2],
    meb: "Hece farkındalığı, açık ve kapalı hece",
  },
  {
    id: "kelime",
    title: "Kelime Pazarı",
    subtitle: "Kelime dağarcığını büyüt",
    image: "/art/island-kelime.jpg",
    grades: [1, 2, 3],
    meb: "Kelime tanıma, zıt ve eş anlamlılar",
  },
  {
    id: "cumle",
    title: "Cümle Atölyesi",
    subtitle: "Düzgün cümle kur",
    image: "/art/island-cumle.jpg",
    grades: [2, 3],
    meb: "Cümle öğeleri, noktalama, bağlaçlar",
  },
  {
    id: "hikaye",
    title: "Hikaye Ormanı",
    subtitle: "Olayı sıraya koy, anlat",
    image: "/art/island-hikaye.jpg",
    grades: [2, 3, 4],
    meb: "Anlatı: kahraman, yer, zaman, olay sırası",
  },
  {
    id: "kompozisyon",
    title: "Kompozisyon Kulesi",
    subtitle: "Giriş, gelişme, sonuç",
    image: "/art/island-kompozisyon.jpg",
    grades: [3, 4],
    meb: "Yazılı anlatım: plan, ana fikir, türler",
  },
];

export const lessons: Lesson[] = [
  {
    id: "harf-ela",
    islandId: "harf",
    title: "e, l, a sesleri",
    subtitle: "İlk ses grubu",
    grades: [1],
    questions: [
      {
        type: "choice",
        id: "h1",
        prompt: "elma kelimesi hangi sesle başlar?",
        speak: "elma. Elma kelimesi hangi sesle başlar?",
        hint: "Eeee-lma diye seslendir.",
        options: [
          { id: "e", label: "e" },
          { id: "a", label: "a" },
          { id: "l", label: "l" },
        ],
        correctId: "e",
      },
      {
        type: "choice",
        id: "h2",
        prompt: "lale kelimesi hangi sesle başlar?",
        speak: "lale. Lale kelimesi hangi sesle başlar?",
        hint: "Lale, l sesiyle başlar.",
        options: [
          { id: "e", label: "e" },
          { id: "l", label: "l" },
          { id: "a", label: "a" },
        ],
        correctId: "l",
      },
      {
        type: "choice",
        id: "h3",
        prompt: "Hangi kelime a sesiyle başlar?",
        speak: "Hangi kelime a sesiyle başlar?",
        options: [
          { id: "elma", label: "elma" },
          { id: "lale", label: "lale" },
          { id: "ana", label: "ana" },
        ],
        correctId: "ana",
      },
      {
        type: "spell",
        id: "h4",
        prompt: "Dinle ve yaz. Bu kelimeyi yaz.",
        speak: "lale",
        hint: "Üç harf: l, a, l, e… lale.",
        answer: "lale",
      },
      {
        type: "choice",
        id: "h5",
        prompt: "ele kelimesindeki ilk ses hangisi?",
        speak: "ele. İlk ses hangisi?",
        options: [
          { id: "e", label: "e" },
          { id: "l", label: "l" },
          { id: "k", label: "k" },
        ],
        correctId: "e",
      },
    ],
  },
  {
    id: "harf-kin",
    islandId: "harf",
    title: "k, i, n sesleri",
    subtitle: "İkinci ses grubu",
    grades: [1],
    questions: [
      {
        type: "choice",
        id: "k1",
        prompt: "kalem kelimesi hangi sesle başlar?",
        speak: "kalem. Hangi sesle başlar?",
        options: [
          { id: "k", label: "k" },
          { id: "n", label: "n" },
          { id: "i", label: "i" },
        ],
        correctId: "k",
      },
      {
        type: "choice",
        id: "k2",
        prompt: "inek kelimesi hangi sesle başlar?",
        speak: "inek. Hangi sesle başlar?",
        options: [
          { id: "n", label: "n" },
          { id: "i", label: "i" },
          { id: "k", label: "k" },
        ],
        correctId: "i",
      },
      {
        type: "choice",
        id: "k3",
        prompt: "Hangi kelime n sesiyle başlar?",
        speak: "Hangi kelime n sesiyle başlar?",
        options: [
          { id: "nane", label: "nane" },
          { id: "elma", label: "elma" },
          { id: "kalem", label: "kalem" },
        ],
        correctId: "nane",
      },
      {
        type: "spell",
        id: "k4",
        prompt: "Dinle ve yaz.",
        speak: "kalem",
        hint: "ka-lem",
        answer: "kalem",
      },
      {
        type: "order",
        id: "k5",
        prompt: "Harfleri doğru sıraya koy: inek",
        speak: "inek kelimesini harflerden kur.",
        tiles: ["i", "n", "e", "k"],
        correct: ["i", "n", "e", "k"],
      },
    ],
  },
  {
    id: "harf-omut",
    islandId: "harf",
    title: "o, m, u, t sesleri",
    subtitle: "Yeni sesler",
    grades: [1],
    questions: [
      {
        type: "choice",
        id: "o1",
        prompt: "okul kelimesi hangi sesle başlar?",
        speak: "okul. Hangi sesle başlar?",
        options: [
          { id: "o", label: "o" },
          { id: "u", label: "u" },
          { id: "m", label: "m" },
        ],
        correctId: "o",
      },
      {
        type: "choice",
        id: "o2",
        prompt: "Hangi kelime m sesiyle başlar?",
        speak: "Hangi kelime m sesiyle başlar?",
        options: [
          { id: "top", label: "top" },
          { id: "muz", label: "muz" },
          { id: "okul", label: "okul" },
        ],
        correctId: "muz",
      },
      {
        type: "choice",
        id: "o3",
        prompt: "top kelimesi hangi sesle başlar?",
        speak: "top. Hangi sesle başlar?",
        options: [
          { id: "t", label: "t" },
          { id: "o", label: "o" },
          { id: "m", label: "m" },
        ],
        correctId: "t",
      },
      {
        type: "spell",
        id: "o4",
        prompt: "Dinle ve yaz.",
        speak: "okul",
        answer: "okul",
        hint: "o-kul",
      },
      {
        type: "order",
        id: "o5",
        prompt: "Harfleri sırala: mut",
        tiles: ["m", "u", "t"],
        correct: ["m", "u", "t"],
        speak: "mut",
      },
    ],
  },
  {
    id: "harf-avi",
    islandId: "harf",
    title: "Harf avı",
    subtitle: "Karışık sesler",
    grades: [1, 2],
    questions: [
      {
        type: "choice",
        id: "a1",
        prompt: "üç kelimesi hangi sesle başlar?",
        speak: "üç. Hangi sesle başlar?",
        options: [
          { id: "u", label: "u" },
          { id: "ü", label: "ü" },
          { id: "ö", label: "ö" },
        ],
        correctId: "ü",
      },
      {
        type: "choice",
        id: "a2",
        prompt: "Hangi harf şeker kelimesinin ilk sesidir?",
        speak: "şeker. İlk ses hangisi?",
        options: [
          { id: "s", label: "s" },
          { id: "ş", label: "ş" },
          { id: "ç", label: "ç" },
        ],
        correctId: "ş",
      },
      {
        type: "choice",
        id: "a3",
        prompt: "çiçek hangi sesle başlar?",
        speak: "çiçek. Hangi sesle başlar?",
        options: [
          { id: "ç", label: "ç" },
          { id: "c", label: "c" },
          { id: "ş", label: "ş" },
        ],
        correctId: "ç",
      },
      {
        type: "choice",
        id: "a4",
        prompt: "Hangi kelime ğ harfini içerir?",
        speak: "Hangi kelimede yumuşak g var?",
        options: [
          { id: "dag", label: "dağ" },
          { id: "el", label: "el" },
          { id: "su", label: "su" },
        ],
        correctId: "dag",
      },
      {
        type: "spell",
        id: "a5",
        prompt: "Dinle ve yaz.",
        speak: "çiçek",
        answer: "çiçek",
        hint: "çi-çek",
      },
    ],
  },
  {
    id: "hece-acik",
    islandId: "hece",
    title: "Açık heceler",
    subtitle: "Sesli harfle biten hece",
    grades: [1, 2],
    questions: [
      {
        type: "choice",
        id: "ha1",
        prompt: "Hangisi açık hecedir?",
        speak: "Hangisi açık hecedir? Açık hece sesli harfle biter.",
        hint: "Açık hece a, e, ı, i, o, ö, u, ü ile biter.",
        options: [
          { id: "ka", label: "ka" },
          { id: "kal", label: "kal" },
          { id: "kart", label: "kart" },
        ],
        correctId: "ka",
      },
      {
        type: "order",
        id: "ha2",
        prompt: "Heceleri birleştir: lale",
        speak: "la ve le. Lale yap.",
        tiles: ["la", "le"],
        correct: ["la", "le"],
      },
      {
        type: "order",
        id: "ha3",
        prompt: "Heceleri birleştir: kedi",
        speak: "ke ve di. Kedi yap.",
        tiles: ["ke", "di"],
        correct: ["ke", "di"],
      },
      {
        type: "choice",
        id: "ha4",
        prompt: "anne kelimesinin heceleri hangisi?",
        speak: "anne. Heceleri nedir?",
        options: [
          { id: "a-nne", label: "a-nne" },
          { id: "an-ne", label: "an-ne" },
          { id: "ann-e", label: "ann-e" },
        ],
        correctId: "an-ne",
      },
      {
        type: "spell",
        id: "ha5",
        prompt: "Dinle ve hece hece yaz: dede",
        speak: "dede",
        answer: "dede",
      },
    ],
  },
  {
    id: "hece-kapali",
    islandId: "hece",
    title: "Kapalı heceler",
    subtitle: "Sessiz harfle biten hece",
    grades: [1, 2],
    questions: [
      {
        type: "choice",
        id: "hk1",
        prompt: "Hangisi kapalı hecedir?",
        speak: "Hangisi kapalı hecedir? Kapalı hece sessiz harfle biter.",
        options: [
          { id: "el", label: "el" },
          { id: "e", label: "e" },
          { id: "la", label: "la" },
        ],
        correctId: "el",
      },
      {
        type: "order",
        id: "hk2",
        prompt: "Heceleri birleştir: kalem",
        speak: "ka ve lem. Kalem yap.",
        tiles: ["ka", "lem"],
        correct: ["ka", "lem"],
      },
      {
        type: "order",
        id: "hk3",
        prompt: "Heceleri birleştir: kitap",
        tiles: ["ki", "tap"],
        correct: ["ki", "tap"],
        speak: "kitap",
      },
      {
        type: "choice",
        id: "hk4",
        prompt: "okul kelimesinin heceleri hangisi?",
        speak: "okul. Heceleri nedir?",
        options: [
          { id: "o-kul", label: "o-kul" },
          { id: "ok-ul", label: "ok-ul" },
          { id: "oku-l", label: "oku-l" },
        ],
        correctId: "o-kul",
      },
      {
        type: "spell",
        id: "hk5",
        prompt: "Dinle ve yaz.",
        speak: "defter",
        answer: "defter",
        hint: "def-ter",
      },
    ],
  },
  {
    id: "hece-kur",
    islandId: "hece",
    title: "Hece kurucu",
    subtitle: "Parçala ve birleştir",
    grades: [1, 2],
    questions: [
      {
        type: "order",
        id: "hc1",
        prompt: "masa kelimesini hecelerden kur",
        tiles: ["ma", "sa"],
        correct: ["ma", "sa"],
        speak: "masa",
      },
      {
        type: "order",
        id: "hc2",
        prompt: "öğretmen kelimesini hecelerden kur",
        tiles: ["öğ", "ret", "men"],
        correct: ["öğ", "ret", "men"],
        speak: "öğretmen",
      },
      {
        type: "choice",
        id: "hc3",
        prompt: "pencerede kaç hece var?",
        speak: "pencere. Kaç hece var? pen-ce-re",
        options: [
          { id: "2", label: "2" },
          { id: "3", label: "3" },
          { id: "4", label: "4" },
        ],
        correctId: "3",
      },
      {
        type: "choice",
        id: "hc4",
        prompt: "Hangisinin hece sayısı daha fazla?",
        speak: "Hangisinin hece sayısı daha fazla? kedi mi, kelebek mi?",
        options: [
          { id: "kedi", label: "kedi" },
          { id: "kelebek", label: "kelebek" },
        ],
        correctId: "kelebek",
      },
      {
        type: "spell",
        id: "hc5",
        prompt: "Dinle ve yaz.",
        speak: "kelebek",
        answer: "kelebek",
      },
    ],
  },
  {
    id: "kelime-sec",
    islandId: "kelime",
    title: "Doğru kelime",
    subtitle: "Anlama göre seç",
    grades: [1, 2],
    questions: [
      {
        type: "choice",
        id: "w1",
        prompt: "Yazı yazdığımız araç hangisi?",
        speak: "Yazı yazdığımız araç hangisi?",
        options: [
          { id: "kalem", label: "kalem" },
          { id: "top", label: "top" },
          { id: "elma", label: "elma" },
        ],
        correctId: "kalem",
      },
      {
        type: "choice",
        id: "w2",
        prompt: "Okulda ders dinlediğimiz kişi kim?",
        speak: "Okulda ders dinlediğimiz kişi kim?",
        options: [
          { id: "ogretmen", label: "öğretmen" },
          { id: "kedi", label: "kedi" },
          { id: "agac", label: "ağaç" },
        ],
        correctId: "ogretmen",
      },
      {
        type: "choice",
        id: "w3",
        prompt: "Gökyüzünde gece parlayan hangisi?",
        speak: "Gökyüzünde gece parlayan hangisi?",
        options: [
          { id: "ay", label: "ay" },
          { id: "deniz", label: "deniz" },
          { id: "ekmek", label: "ekmek" },
        ],
        correctId: "ay",
      },
      {
        type: "spell",
        id: "w4",
        prompt: "Dinle ve yaz.",
        speak: "kitap",
        answer: "kitap",
      },
      {
        type: "choice",
        id: "w5",
        prompt: "Hangisi bir meyvedir?",
        speak: "Hangisi bir meyvedir?",
        options: [
          { id: "armut", label: "armut" },
          { id: "masa", label: "masa" },
          { id: "yol", label: "yol" },
        ],
        correctId: "armut",
      },
    ],
  },
  {
    id: "kelime-zit",
    islandId: "kelime",
    title: "Zıt anlamlılar",
    subtitle: "Karşıtını bul",
    grades: [2, 3],
    questions: [
      {
        type: "choice",
        id: "z1",
        prompt: "büyük kelimesinin zıt anlamı hangisi?",
        speak: "büyük kelimesinin zıt anlamı hangisi?",
        options: [
          { id: "kucuk", label: "küçük" },
          { id: "uzun", label: "uzun" },
          { id: "sicak", label: "sıcak" },
        ],
        correctId: "kucuk",
      },
      {
        type: "choice",
        id: "z2",
        prompt: "açık kelimesinin zıt anlamı hangisi?",
        speak: "açık kelimesinin zıt anlamı hangisi?",
        options: [
          { id: "kapali", label: "kapalı" },
          { id: "yeni", label: "yeni" },
          { id: "temiz", label: "temiz" },
        ],
        correctId: "kapali",
      },
      {
        type: "choice",
        id: "z3",
        prompt: "gece kelimesinin zıt anlamı hangisi?",
        speak: "gece kelimesinin zıt anlamı hangisi?",
        options: [
          { id: "gunduz", label: "gündüz" },
          { id: "yildiz", label: "yıldız" },
          { id: "uyku", label: "uyku" },
        ],
        correctId: "gunduz",
      },
      {
        type: "choice",
        id: "z4",
        prompt: "sıcak kelimesinin zıt anlamı hangisi?",
        speak: "sıcak kelimesinin zıt anlamı hangisi?",
        options: [
          { id: "soguk", label: "soğuk" },
          { id: "ates", label: "ateş" },
          { id: "yaz", label: "yaz" },
        ],
        correctId: "soguk",
      },
      {
        type: "choice",
        id: "z5",
        prompt: "yavaş kelimesinin zıt anlamı hangisi?",
        speak: "yavaş kelimesinin zıt anlamı hangisi?",
        options: [
          { id: "hizli", label: "hızlı" },
          { id: "sessiz", label: "sessiz" },
          { id: "kisa", label: "kısa" },
        ],
        correctId: "hizli",
      },
    ],
  },
  {
    id: "kelime-es",
    islandId: "kelime",
    title: "Eş anlamlılar",
    subtitle: "Aynı anlama gelen kelime",
    grades: [2, 3],
    questions: [
      {
        type: "choice",
        id: "e1",
        prompt: "güzel kelimesinin eş anlamlısı hangisi?",
        speak: "güzel kelimesinin eş anlamlısı hangisi?",
        options: [
          { id: "cirkin", label: "çirkin" },
          { id: "hoş", label: "hoş" },
          { id: "buyuk", label: "büyük" },
        ],
        correctId: "hoş",
      },
      {
        type: "choice",
        id: "e2",
        prompt: "ev kelimesinin eş anlamlısı hangisi?",
        speak: "ev kelimesinin eş anlamlısı hangisi?",
        options: [
          { id: "yurt", label: "yurt" },
          { id: "okul", label: "okul" },
          { id: "yol", label: "yol" },
        ],
        correctId: "yurt",
      },
      {
        type: "choice",
        id: "e3",
        prompt: "öğrenci kelimesinin eş anlamlısı hangisi?",
        speak: "öğrenci kelimesinin eş anlamlısı hangisi?",
        options: [
          { id: "talebe", label: "talebe" },
          { id: "ogretmen", label: "öğretmen" },
          { id: "mudur", label: "müdür" },
        ],
        correctId: "talebe",
      },
      {
        type: "choice",
        id: "e4",
        prompt: "hızlı kelimesinin eş anlamlısı hangisi?",
        speak: "hızlı kelimesinin eş anlamlısı hangisi?",
        options: [
          { id: "cabuk", label: "çabuk" },
          { id: "yavas", label: "yavaş" },
          { id: "uzun", label: "uzun" },
        ],
        correctId: "cabuk",
      },
      {
        type: "spell",
        id: "e5",
        prompt: "Dinle ve yaz: merhaba ile aynı anlamda bir söz.",
        speak: "selam",
        answer: "selam",
        hint: "merhaba = selam",
      },
    ],
  },
  {
    id: "cumle-sira",
    islandId: "cumle",
    title: "Karışık cümle",
    subtitle: "Kelimeleri sıraya koy",
    grades: [2, 3],
    questions: [
      {
        type: "order",
        id: "c1",
        prompt: "Cümleyi doğru sıraya koy.",
        speak: "Ali parkta top oynadı.",
        tiles: ["Ali", "parkta", "top", "oynadı."],
        correct: ["Ali", "parkta", "top", "oynadı."],
      },
      {
        type: "order",
        id: "c2",
        prompt: "Cümleyi doğru sıraya koy.",
        speak: "Kedi sütü içti.",
        tiles: ["Kedi", "sütü", "içti."],
        correct: ["Kedi", "sütü", "içti."],
      },
      {
        type: "order",
        id: "c3",
        prompt: "Cümleyi doğru sıraya koy.",
        speak: "Annem güzel pasta yaptı.",
        tiles: ["Annem", "güzel", "pasta", "yaptı."],
        correct: ["Annem", "güzel", "pasta", "yaptı."],
      },
      {
        type: "choice",
        id: "c4",
        prompt: "Hangisi doğru bir cümledir?",
        speak: "Hangisi doğru bir cümledir?",
        options: [
          { id: "ok", label: "Bugün hava çok güzel." },
          { id: "no", label: "güzel hava bugün çok" },
        ],
        correctId: "ok",
      },
      {
        type: "order",
        id: "c5",
        prompt: "Cümleyi doğru sıraya koy.",
        speak: "Çocuklar bahçede koşuyor.",
        tiles: ["Çocuklar", "bahçede", "koşuyor."],
        correct: ["Çocuklar", "bahçede", "koşuyor."],
      },
    ],
  },
  {
    id: "cumle-nokta",
    islandId: "cumle",
    title: "Büyük harf ve nokta",
    subtitle: "Cümle kuralları",
    grades: [2, 3],
    questions: [
      {
        type: "choice",
        id: "n1",
        prompt: "Cümleler hangi harfle başlar?",
        speak: "Cümleler hangi harfle başlar?",
        options: [
          { id: "buyuk", label: "Büyük harfle" },
          { id: "kucuk", label: "Küçük harfle" },
        ],
        correctId: "buyuk",
      },
      {
        type: "choice",
        id: "n2",
        prompt: "Hangisi doğru yazılmış?",
        speak: "Hangisi doğru yazılmış?",
        options: [
          { id: "ok", label: "Sabah okula gittim." },
          { id: "no", label: "sabah okula gittim" },
        ],
        correctId: "ok",
      },
      {
        type: "choice",
        id: "n3",
        prompt: "Soru cümlesinin sonunda ne olur?",
        speak: "Soru cümlesinin sonunda ne olur?",
        options: [
          { id: "soru", label: "Soru işareti (?)" },
          { id: "nokta", label: "Nokta (.)" },
          { id: "unlem", label: "Ünlem (!)" },
        ],
        correctId: "soru",
      },
      {
        type: "choice",
        id: "n4",
        prompt: "Hangisi soru cümlesidir?",
        speak: "Hangisi soru cümlesidir?",
        options: [
          { id: "q", label: "Adın ne?" },
          { id: "s", label: "Adım Elif." },
        ],
        correctId: "q",
      },
      {
        type: "choice",
        id: "n5",
        prompt: "Sevinç cümlesinin sonunda ne olur?",
        speak: "Yaşasın tatil gibi cümlelerin sonunda ne olur?",
        options: [
          { id: "unlem", label: "Ünlem (!)" },
          { id: "soru", label: "Soru işareti (?)" },
        ],
        correctId: "unlem",
      },
    ],
  },
  {
    id: "cumle-baglac",
    islandId: "cumle",
    title: "Bağlaçlar",
    subtitle: "ve, ile, ama, çünkü",
    grades: [2, 3, 4],
    questions: [
      {
        type: "choice",
        id: "b1",
        prompt: "Ali … Ayşe parka gitti. Boşluğa ne gelir?",
        speak: "Ali ve Ayşe parka gitti. Boşluğa ne gelir?",
        options: [
          { id: "ve", label: "ve" },
          { id: "ama", label: "ama" },
          { id: "cunku", label: "çünkü" },
        ],
        correctId: "ve",
      },
      {
        type: "choice",
        id: "b2",
        prompt: "Dışarı çıkmadım … hava yağmurluydu.",
        speak: "Dışarı çıkmadım çünkü hava yağmurluydu. Boşluğa ne gelir?",
        hint: "Nedenini anlatan bağlaç çünkü.",
        options: [
          { id: "cunku", label: "çünkü" },
          { id: "ile", label: "ile" },
          { id: "ve", label: "ve" },
        ],
        correctId: "cunku",
      },
      {
        type: "choice",
        id: "b3",
        prompt: "Koşmak istedim … ayağım ağrıyordu.",
        speak: "Koşmak istedim ama ayağım ağrıyordu.",
        options: [
          { id: "ama", label: "ama" },
          { id: "ile", label: "ile" },
          { id: "ve", label: "ve" },
        ],
        correctId: "ama",
      },
      {
        type: "choice",
        id: "b4",
        prompt: "Hangisi iki cümleyi zıtlıkla bağlar?",
        speak: "Hangisi iki cümleyi zıtlıkla bağlar?",
        options: [
          { id: "ama", label: "ama" },
          { id: "ve", label: "ve" },
          { id: "ile", label: "ile" },
        ],
        correctId: "ama",
      },
      {
        type: "order",
        id: "b5",
        prompt: "Cümleyi kur.",
        speak: "Elma ve armut aldım.",
        tiles: ["Elma", "ve", "armut", "aldım."],
        correct: ["Elma", "ve", "armut", "aldım."],
      },
    ],
  },
  {
    id: "hikaye-sira",
    islandId: "hikaye",
    title: "Olay sırası",
    subtitle: "Önce, sonra, en sonra",
    grades: [2, 3, 4],
    questions: [
      {
        type: "order",
        id: "s1",
        prompt: "Hikayeyi doğru sıraya koy.",
        speak: "Sabah kalktım. Kahvaltı yaptım. Okula gittim.",
        tiles: ["Sabah kalktım.", "Kahvaltı yaptım.", "Okula gittim."],
        correct: ["Sabah kalktım.", "Kahvaltı yaptım.", "Okula gittim."],
      },
      {
        type: "order",
        id: "s2",
        prompt: "Tohumun hikayesini sırala.",
        speak: "Tohum ekildi. Filiz çıktı. Çiçek açtı.",
        tiles: ["Tohum ekildi.", "Filiz çıktı.", "Çiçek açtı."],
        correct: ["Tohum ekildi.", "Filiz çıktı.", "Çiçek açtı."],
      },
      {
        type: "choice",
        id: "s3",
        prompt: "Hikayede olaylar nasıl anlatılır?",
        speak: "Hikayede olaylar nasıl anlatılır?",
        options: [
          { id: "sira", label: "Sırayla" },
          { id: "karisik", label: "Karışık" },
        ],
        correctId: "sira",
      },
      {
        type: "choice",
        id: "s4",
        prompt: "Bir hikayede kahraman kimdir?",
        speak: "Bir hikayede kahraman kimdir?",
        options: [
          { id: "kisi", label: "Olayı yaşayan kişi veya varlık" },
          { id: "yer", label: "Olayın geçtiği yer" },
        ],
        correctId: "kisi",
      },
      {
        type: "choice",
        id: "s5",
        prompt: "Yağmur yağdı. … sokaklar ıslandı. Boşluğa ne gelir?",
        speak: "Yağmur yağdı. Sonra sokaklar ıslandı.",
        options: [
          { id: "sonra", label: "Sonra" },
          { id: "once", label: "Önce" },
        ],
        correctId: "sonra",
      },
    ],
  },
  {
    id: "hikaye-oge",
    islandId: "hikaye",
    title: "Hikaye ögeleri",
    subtitle: "Kahraman, yer, zaman",
    grades: [2, 3, 4],
    questions: [
      {
        type: "choice",
        id: "o1",
        prompt: "Keloğlan ormanda sabah yürüdü. Kahraman kim?",
        speak: "Keloğlan ormanda sabah yürüdü. Kahraman kim?",
        options: [
          { id: "k", label: "Keloğlan" },
          { id: "o", label: "Orman" },
          { id: "s", label: "Sabah" },
        ],
        correctId: "k",
      },
      {
        type: "choice",
        id: "o2",
        prompt: "Keloğlan ormanda sabah yürüdü. Yer neresi?",
        speak: "Yer neresi?",
        options: [
          { id: "o", label: "Orman" },
          { id: "k", label: "Keloğlan" },
          { id: "s", label: "Sabah" },
        ],
        correctId: "o",
      },
      {
        type: "choice",
        id: "o3",
        prompt: "Keloğlan ormanda sabah yürüdü. Zaman nedir?",
        speak: "Zaman nedir?",
        options: [
          { id: "s", label: "Sabah" },
          { id: "o", label: "Orman" },
          { id: "k", label: "Keloğlan" },
        ],
        correctId: "s",
      },
      {
        type: "choice",
        id: "o4",
        prompt: "Hikayenin sonu nasıl olmalı?",
        speak: "Hikayenin sonu nasıl olmalı?",
        options: [
          { id: "bitis", label: "Olay bir sonuca bağlanmalı" },
          { id: "yarim", label: "Yarım kalabilir" },
        ],
        correctId: "bitis",
      },
      {
        type: "write",
        id: "o5",
        prompt:
          "Kısa bir hikaye yaz. Kahraman, yer ve zamanı belirt. En az 20 kelime.",
        speak: "Kısa bir hikaye yaz. Kahramanı, yeri ve zamanı söyle.",
        minWords: 20,
        starters: [
          "Bir sabah",
          "Kahramanım",
          "Sonunda",
        ],
        hint: "Kim, nerede, ne zaman, ne oldu?",
      },
    ],
  },
  {
    id: "hikaye-yaz",
    islandId: "hikaye",
    title: "Mini hikaye",
    subtitle: "Kendi hikayeni yaz",
    grades: [2, 3, 4],
    questions: [
      {
        type: "choice",
        id: "hy1",
        prompt: "İyi bir hikaye başlığı hangisi?",
        speak: "İyi bir hikaye başlığı hangisi?",
        options: [
          { id: "ok", label: "Kayıp Kırmızı Top" },
          { id: "no", label: "hikaye" },
        ],
        correctId: "ok",
      },
      {
        type: "write",
        id: "hy2",
        prompt:
          "Kayıp bir kırmızı top hakkında kısa bir hikaye yaz. Girişte kim ve nerede olduğunu söyle.",
        speak:
          "Kayıp bir kırmızı top hakkında kısa bir hikaye yaz.",
        minWords: 28,
        scaffold: [
          {
            title: "Başlangıç",
            placeholder: "Kim, nerede, ne arıyor?",
          },
          {
            title: "Orta",
            placeholder: "Topu ararken neler oldu?",
          },
          {
            title: "Son",
            placeholder: "Top bulundu mu? Nasıl bitti?",
          },
        ],
      },
    ],
  },
  {
    id: "komp-yapi",
    islandId: "kompozisyon",
    title: "Üç bölüm",
    subtitle: "Giriş, gelişme, sonuç",
    grades: [3, 4],
    questions: [
      {
        type: "choice",
        id: "ky1",
        prompt: "Kompozisyonun ilk bölümü nedir?",
        speak: "Kompozisyonun ilk bölümü nedir?",
        options: [
          { id: "giris", label: "Giriş" },
          { id: "sonuc", label: "Sonuç" },
          { id: "baslik", label: "Sadece başlık" },
        ],
        correctId: "giris",
      },
      {
        type: "choice",
        id: "ky2",
        prompt: "Gelişme bölümünde ne yaparız?",
        speak: "Gelişme bölümünde ne yaparız?",
        options: [
          { id: "ornek", label: "Konuyu örneklerle açıklarız" },
          { id: "bitir", label: "Yazıyı bitiririz" },
        ],
        correctId: "ornek",
      },
      {
        type: "choice",
        id: "ky3",
        prompt: "Sonuç bölümünde ne olur?",
        speak: "Sonuç bölümünde ne olur?",
        options: [
          { id: "ozet", label: "Ana fikir toparlanır" },
          { id: "yeni", label: "Bambaşka bir konu açılır" },
        ],
        correctId: "ozet",
      },
      {
        type: "choice",
        id: "ky4",
        prompt: "Ana fikir nedir?",
        speak: "Ana fikir nedir?",
        options: [
          { id: "ana", label: "Yazarın asıl söylemek istediği" },
          { id: "baslik", label: "Sadece yazının adı" },
        ],
        correctId: "ana",
      },
      {
        type: "choice",
        id: "ky5",
        prompt: "Hangisi iyi bir giriş cümlesidir?",
        speak: "Hangisi iyi bir giriş cümlesidir?",
        options: [
          { id: "ok", label: "Kitap okumak hayal gücümü büyütür." },
          { id: "no", label: "Sonra evde yemek yedim." },
        ],
        correctId: "ok",
      },
    ],
  },
  {
    id: "komp-mektup",
    islandId: "kompozisyon",
    title: "Mektup yaz",
    subtitle: "Sevgili…, kapanış",
    grades: [3, 4],
    questions: [
      {
        type: "choice",
        id: "m1",
        prompt: "Mektup nasıl başlar?",
        speak: "Mektup nasıl başlar?",
        options: [
          { id: "ok", label: "Sevgili …" },
          { id: "no", label: "Sonuç olarak …" },
        ],
        correctId: "ok",
      },
      {
        type: "choice",
        id: "m2",
        prompt: "Mektubun sonunda ne yazarız?",
        speak: "Mektubun sonunda ne yazarız?",
        options: [
          { id: "ok", label: "Seni seven … ve adımız" },
          { id: "no", label: "Soru işareti" },
        ],
        correctId: "ok",
      },
      {
        type: "write",
        id: "m3",
        prompt:
          "Bir arkadaşına kısa bir mektup yaz. Nasıl olduğunu sor, bir anını anlat, özlemini söyle.",
        speak: "Bir arkadaşına kısa bir mektup yaz.",
        minWords: 30,
        scaffold: [
          { title: "Hitap", placeholder: "Sevgili …" },
          { title: "Haberler", placeholder: "Neler yaptığını anlat." },
          { title: "Kapanış", placeholder: "Özlemini söyle ve adını yaz." },
        ],
      },
    ],
  },
  {
    id: "komp-betim",
    islandId: "kompozisyon",
    title: "Betimleme",
    subtitle: "Gördüğünü anlat",
    grades: [3, 4],
    questions: [
      {
        type: "choice",
        id: "be1",
        prompt: "Betimleme nedir?",
        speak: "Betimleme nedir?",
        options: [
          { id: "ok", label: "Bir yeri veya varlığı ayrıntılarıyla anlatmak" },
          { id: "no", label: "Sadece isim yazmak" },
        ],
        correctId: "ok",
      },
      {
        type: "choice",
        id: "be2",
        prompt: "Betimlerken hangi duyulara yer veririz?",
        speak: "Betimlerken hangi duyulara yer veririz?",
        options: [
          { id: "ok", label: "Görme, işitme, koklama, dokunma" },
          { id: "no", label: "Sadece sayılar" },
        ],
        correctId: "ok",
      },
      {
        type: "write",
        id: "be3",
        prompt:
          "Sınıfını veya odanı betimle. Renkleri, sesleri ve hissettirdiklerini yaz. En az 30 kelime.",
        speak: "Sınıfını veya odanı betimle. Renkleri ve sesleri söyle.",
        minWords: 30,
        starters: [
          "Odaya girince",
          "Pencereden",
          "En sevdiğim köşe",
        ],
      },
    ],
  },
  {
    id: "komp-yaz",
    islandId: "kompozisyon",
    title: "İlk kompozisyon",
    subtitle: "Planlı yazı",
    grades: [3, 4],
    questions: [
      {
        type: "write",
        id: "kw1",
        prompt:
          "Konu: En sevdiğim mevsim. Giriş, gelişme ve sonuç bölümleriyle bir kompozisyon yaz.",
        speak:
          "En sevdiğin mevsimi anlat. Giriş, gelişme ve sonuç yaz.",
        minWords: 40,
        scaffold: [
          {
            title: "Giriş",
            placeholder: "Hangi mevsimi seviyorsun? Bir cümleyle tanıt.",
          },
          {
            title: "Gelişme",
            placeholder:
              "Neden? Neler yaparsın? Bir anını anlat. En az iki cümle.",
          },
          {
            title: "Sonuç",
            placeholder: "Duygunu ve ana fikrini bir cümlede bitir.",
          },
        ],
      },
    ],
  },
];

export const writingPrompts: WritingPrompt[] = [
  {
    id: "hayvan",
    kind: "kompozisyon",
    title: "En sevdiğim hayvan",
    blurb: "Onu neden sevdiğini anlat.",
    grades: [1, 2, 3, 4],
    starters: [
      "Benim en sevdiğim hayvan",
      "O çok",
      "Birlikte",
    ],
    scaffold: [
      { title: "Giriş", placeholder: "Hangi hayvan? Neden onu seçtin?" },
      { title: "Gelişme", placeholder: "Nasıl görünür, ne yapar, bir anın." },
      { title: "Sonuç", placeholder: "Sana ne hissettiriyor?" },
    ],
  },
  {
    id: "okul",
    kind: "kompozisyon",
    title: "Okulum",
    blurb: "Okulunu tanıtan bir yazı.",
    grades: [2, 3, 4],
    starters: ["Benim okulum", "Bahçesinde", "En sevdiğim ders"],
    scaffold: [
      { title: "Giriş", placeholder: "Okulunun adını ve yerini söyle." },
      { title: "Gelişme", placeholder: "Sınıf, bahçe, arkadaşlar, bir anı." },
      { title: "Sonuç", placeholder: "Okulunu neden sevdiğini bitir." },
    ],
  },
  {
    id: "mevsim",
    kind: "kompozisyon",
    title: "En sevdiğim mevsim",
    blurb: "Klasik MEB kompozisyon konusu.",
    grades: [2, 3, 4],
    starters: ["En sevdiğim mevsim", "Bu mevsimde", "Hava"],
    scaffold: [
      { title: "Giriş", placeholder: "Mevsimi tanıt." },
      { title: "Gelişme", placeholder: "Doğa, oyunlar, giysiler, bir anı." },
      { title: "Sonuç", placeholder: "Ana fikrini söyle." },
    ],
  },
  {
    id: "arkadas",
    kind: "betimleme",
    title: "En iyi arkadaşım",
    blurb: "Dış görünüş ve kişilik.",
    grades: [2, 3, 4],
    starters: ["En iyi arkadaşım", "O", "Birlikte"],
    scaffold: [
      { title: "Görünüş", placeholder: "Saç, göz, gülüş…" },
      { title: "Kişilik", placeholder: "Nasıl biri? Ne yapmayı sever?" },
      { title: "Bir anı", placeholder: "Birlikte yaşadığınız kısa bir olay." },
    ],
  },
  {
    id: "park",
    kind: "betimleme",
    title: "Mahalle parkı",
    blurb: "Gördüğünü, duyduğunu yaz.",
    grades: [3, 4],
    starters: ["Parka girince", "Çocuklar", "Ağaçların arasında"],
    scaffold: [
      { title: "Giriş", placeholder: "Park nerededir, ne zaman gittin?" },
      { title: "Gelişme", placeholder: "Renkler, sesler, kokular, oyunlar." },
      { title: "Sonuç", placeholder: "Sende bıraktığı duygu." },
    ],
  },
  {
    id: "mektup-dede",
    kind: "mektup",
    title: "Dedeye / ninneye mektup",
    blurb: "Hitap, haber, özlem, kapanış.",
    grades: [2, 3, 4],
    starters: ["Sevgili", "Ben iyiyim", "Seni çok"],
    scaffold: [
      { title: "Hitap", placeholder: "Sevgili dede / ninenin adı," },
      { title: "Haberler", placeholder: "Okul, oyun, bir güzel an." },
      { title: "Kapanış", placeholder: "Öpüyorum, adın." },
    ],
  },
  {
    id: "gunluk",
    kind: "gunluk",
    title: "Bugünkü günlüğüm",
    blurb: "Tarih, olay, duygu.",
    grades: [2, 3, 4],
    starters: ["Bugün", "En güzel an", "Yarın"],
    scaffold: [
      { title: "Tarih ve giriş", placeholder: "Bugün … oldu." },
      { title: "Olay", placeholder: "Ne yaşadın? Kimler vardı?" },
      { title: "Duygu", placeholder: "Nasıl hissettin, yarına notun." },
    ],
  },
  {
    id: "kayip-kedi",
    kind: "hikaye",
    title: "Kayıp kedi",
    blurb: "Kahraman, yer, zaman, sonuç.",
    grades: [2, 3, 4],
    starters: ["Bir akşam", "Kediyi ararken", "Sonunda"],
    scaffold: [
      { title: "Başlangıç", placeholder: "Kim, nerede, kedi nasıl kayboldu?" },
      { title: "Arayış", placeholder: "Nereye bakıldı, kim yardım etti?" },
      { title: "Son", placeholder: "Kedi bulundu mu? Nasıl bitti?" },
    ],
  },
  {
    id: "sihirli-kalem",
    kind: "hikaye",
    title: "Sihirli kalem",
    blurb: "Yazdığı her şey gerçek oluyor.",
    grades: [3, 4],
    starters: ["Bir gün kalemim", "İlk yazdığım şey", "Sonra"],
    scaffold: [
      { title: "Giriş", placeholder: "Kalemi nasıl buldun?" },
      { title: "Gelişme", placeholder: "Ne yazdın, ne oldu?" },
      { title: "Sonuç", placeholder: "Dersi / mesajı nedir?" },
    ],
  },
  {
    id: "davet",
    kind: "davetiye",
    title: "Doğum günü davetiyesi",
    blurb: "Kim, nerede, ne zaman, ne için.",
    grades: [1, 2, 3],
    starters: ["Sevgili", "Seni", "Tarih"],
    scaffold: [
      { title: "Kime", placeholder: "Sevgili …" },
      { title: "Ne için", placeholder: "Doğum günüme gelir misin?" },
      { title: "Yer ve zaman", placeholder: "Tarih, saat, adres." },
    ],
  },
  {
    id: "kitap",
    kind: "kompozisyon",
    title: "Kitap okumanın yararı",
    blurb: "Düşünce yazısına ilk adım.",
    grades: [4],
    starters: ["Kitap okumak", "Örneğin", "Sonuç olarak"],
    scaffold: [
      { title: "Giriş", placeholder: "Ana fikrini bir cümlede söyle." },
      {
        title: "Gelişme",
        placeholder: "İki neden ve bir örnek ver.",
      },
      { title: "Sonuç", placeholder: "Okuyucuya bir çağrı ile bitir." },
    ],
  },
  {
    id: "yardim",
    kind: "kompozisyon",
    title: "Yardımlaşmak",
    blurb: "Değerler eğitimi ile yazma.",
    grades: [3, 4],
    starters: ["Yardımlaşmak", "Bir gün", "Bence"],
    scaffold: [
      { title: "Giriş", placeholder: "Yardımlaşmak nedir?" },
      { title: "Gelişme", placeholder: "Okulda veya evde bir örnek." },
      { title: "Sonuç", placeholder: "Neden önemli?" },
    ],
  },
];

export const badges = [
  { id: "ilk-yaprak", title: "İlk yaprak", hint: "İlk dersini bitir." },
  { id: "harf-bahcivan", title: "Harf bahçıvanı", hint: "Harf Bahçesi’ni tamamla." },
  { id: "hececi", title: "Hece ustası", hint: "Hece Deresi’ni tamamla." },
  { id: "kelime-avcisi", title: "Kelime avcısı", hint: "Kelime Pazarı’nı tamamla." },
  { id: "cumle-usta", title: "Cümle ustası", hint: "Cümle Atölyesi’ni tamamla." },
  { id: "anlatici", title: "Hikaye anlatıcısı", hint: "Hikaye Ormanı’nı tamamla." },
  { id: "yazar", title: "Minik yazar", hint: "Kompozisyon Kulesi’nde bir ders bitir." },
  { id: "defter", title: "Defter dolsun", hint: "Üç yazı kaydet." },
  { id: "dinleyici", title: "Kulakları açık", hint: "On kez dinle." },
  { id: "yaprak-20", title: "Yaprak çelengi", hint: "20 yaprak topla." },
] as const;

export function lessonById(id: string) {
  return lessons.find((lesson) => lesson.id === id);
}

export function islandById(id: string) {
  return islands.find((island) => island.id === id);
}

export function lessonsForIsland(id: IslandId) {
  return lessons.filter((lesson) => lesson.islandId === id);
}

export function promptById(id: string) {
  return writingPrompts.find((prompt) => prompt.id === id);
}

export const kindLabels: Record<WritingPrompt["kind"], string> = {
  hikaye: "Hikaye",
  betimleme: "Betimleme",
  mektup: "Mektup",
  gunluk: "Günlük",
  kompozisyon: "Kompozisyon",
  davetiye: "Davetiye",
};

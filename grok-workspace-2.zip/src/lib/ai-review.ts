import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const Input = z.object({
  title: z.string().max(120),
  text: z.string().min(1).max(4000),
  grade: z.number().int().min(1).max(4),
  kind: z.string().max(40),
});

export type ReviewResult =
  | {
      ok: true;
      praise: string;
      tips: string[];
      stars: number;
      nextStep: string;
    }
  | { ok: false; error: string };

export const reviewWriting = createServerFn({ method: "POST" })
  .validator((input: unknown) => Input.parse(input))
  .handler(async ({ data }): Promise<ReviewResult> => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) {
      return { ok: false, error: "Öğretmen şu anda dinleniyor." };
    }

    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "grok-4.5",
        temperature: 0.4,
        max_tokens: 360,
        response_format: { type: "json_object" },
        messages: [
          {
            role: "system",
            content:
              "Sen Turkiye MEB 1-4. sinif Turkce yazma ogretmenisin. Cocuklara nazik, somut ve kisa geri bildirim verirsin. Asla kucumseme, alay etme veya sert olma. Once ov, sonra en fazla 2 oneri ver. Cocugun metnini bastan yazma. JSON uret: {\"praise\":\"...\",\"tips\":[\"...\"],\"stars\":1|2|3,\"nextStep\":\"...\"}. Turkce yaz. Yasina uygun dil kullan.",
          },
          {
            role: "user",
            content: `Sinif: ${data.grade}. Tur: ${data.kind}. Baslik: ${data.title}\n\nYazi:\n${data.text}`,
          },
        ],
      }),
    });

    if (!res.ok) {
      return { ok: false, error: "Öğretmen şu anda yanıt veremedi." };
    }

    const body = (await res.json()) as {
      choices?: { message?: { content?: string } }[];
    };
    const raw = body.choices?.[0]?.message?.content ?? "";
    try {
      const parsed = JSON.parse(raw) as {
        praise?: string;
        tips?: string[];
        stars?: number;
        nextStep?: string;
      };
      const stars = Math.min(3, Math.max(1, Number(parsed.stars) || 2));
      return {
        ok: true,
        praise: parsed.praise?.slice(0, 400) || "Çok emek vermişsin, bravo.",
        tips: (parsed.tips ?? []).slice(0, 2).map((tip) => String(tip).slice(0, 220)),
        stars,
        nextStep: parsed.nextStep?.slice(0, 220) || "Bir sonraki yazıda bir örnek daha ekle.",
      };
    } catch {
      return { ok: false, error: "Öğretmenin notu okunamadı." };
    }
  });

import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { LeafMark } from "@/components/leaf-mark";
import { badges } from "@/lib/curriculum";
import { useProgress } from "@/lib/progress-store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/rozetler")({ component: RozetlerPage });

function RozetlerPage() {
  const earned = useProgress((s) => s.earnedBadges);
  const leaves = useProgress((s) => s.leaves);
  const reset = useProgress((s) => s.reset);
  const name = useProgress((s) => s.name);
  const grade = useProgress((s) => s.grade);

  return (
    <AppShell>
      <p className="text-sm font-medium uppercase tracking-wide text-leaf">Rozetler</p>
      <h1 className="mt-1 font-display text-3xl">Çelengin</h1>
      <section className="mt-5 rounded-2xl bg-page p-5 shadow-border">
        <p className="text-sm text-muted">Sertifika</p>
        <h2 className="mt-1 font-display text-2xl">{name || "Minik yazar"}</h2>
        <p className="mt-2 text-ink-soft">
          {grade}. sınıf yazı bahçesinde {leaves} yaprak topladı.
        </p>
        <div className="mt-3 flex items-center gap-2 text-leaf">
          <LeafMark />
          <span className="font-display tabular-nums">
            {earned.length} / {badges.length} rozet
          </span>
        </div>
      </section>

      <ul className="mt-6 grid grid-cols-1 gap-3 sm:grid-cols-2">
        {badges.map((badge) => {
          const on = earned.includes(badge.id);
          return (
            <li
              key={badge.id}
              className={cn(
                "rounded-2xl p-4 shadow-border",
                on ? "bg-leaf-soft" : "bg-page opacity-70",
              )}
            >
              <div className={on ? "text-leaf" : "text-muted"}>
                <LeafMark className="size-6" />
              </div>
              <h3 className="mt-2 font-display text-lg">{badge.title}</h3>
              <p className="text-sm text-ink-soft">{badge.hint}</p>
            </li>
          );
        })}
      </ul>

      <div className="mt-10">
        <Button
          variant="ghost"
          onClick={() => {
            if (window.confirm("Bahçeyi baştan mı açalım? İlerleme silinir.")) reset();
          }}
        >
          Bahçeyi sıfırla
        </Button>
      </div>
    </AppShell>
  );
}

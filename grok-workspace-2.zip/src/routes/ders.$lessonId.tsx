import { createFileRoute, Navigate } from "@tanstack/react-router";
import { LessonEngine } from "@/components/lesson-engine";
import { lessonById } from "@/lib/curriculum";

export const Route = createFileRoute("/ders/$lessonId")({ component: DersPage });

function DersPage() {
  const { lessonId } = Route.useParams();
  const lesson = lessonById(lessonId);
  if (!lesson) return <Navigate to="/harita" />;
  return <LessonEngine lesson={lesson} />;
}

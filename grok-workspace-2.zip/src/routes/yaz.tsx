import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { WriterStudio } from "@/components/writer-studio";

export const Route = createFileRoute("/yaz")({ component: YazPage });

function YazPage() {
  return (
    <AppShell>
      <p className="text-sm font-medium uppercase tracking-wide text-leaf">Yazı defteri</p>
      <h1 className="mt-1 font-display text-3xl">Konu seç, üç bölümle yaz</h1>
      <p className="mb-5 mt-2 text-ink-soft">
        Mektup, günlük, hikaye ve kompozisyon MEB yazma türlerine göre hazırlandı. Dilersen
        öğretmene göster.
      </p>
      <WriterStudio />
    </AppShell>
  );
}

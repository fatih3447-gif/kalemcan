import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { islands } from "@/lib/curriculum";
import { islandProgress, recommendedIslandIds, useProgress } from "@/lib/progress-store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/harita")({ component: HaritaPage });

function HaritaPage() {
  const name = useProgress((s) => s.name);
  const grade = useProgress((s) => s.grade);
  const stars = useProgress((s) => s.stars);
  const recommended = recommendedIslandIds(grade);

  return (
    <AppShell>
      <div className="stagger-in">
        <p className="text-sm font-medium uppercase tracking-wide text-leaf">Yazı bahçesi</p>
        <h1 className="mt-1 font-display text-3xl">
          {name ? `${name}, bugün nereye?` : "Bugün nereye?"}
        </h1>
        <p className="mt-2 max-w-prose text-ink-soft">
          {grade}. sınıf için önerilen adalar yaprakla işaretli. İstediğin adaya girebilirsin.
        </p>
      </div>

      <ol className="relative mt-8 space-y-5 before:absolute before:bottom-8 before:left-7 before:top-8 before:w-px before:bg-line">
        {islands.map((island, i) => {
          const { done, total } = islandProgress(island.id, stars);
          const isRec = recommended.includes(island.id);
          return (
            <li key={island.id} className="relative pl-0">
              <Link
                to="/ada/$islandId"
                params={{ islandId: island.id }}
                className="flex gap-4 rounded-2xl bg-page p-3 shadow-border transition-[transform,box-shadow] duration-150 hover:shadow-border-hover active:scale-[0.99]"
              >
                <img
                  src={island.image}
                  alt=""
                  className="size-24 shrink-0 rounded-xl object-cover sm:size-28"
                />
                <div className="min-w-0 py-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <h2 className="font-display text-xl">{island.title}</h2>
                    {isRec && (
                      <span className="rounded-md bg-leaf-soft px-2 py-0.5 text-xs font-medium text-leaf">
                        Sana uygun
                      </span>
                    )}
                  </div>
                  <p className="mt-1 text-sm text-ink-soft">{island.subtitle}</p>
                  <p className="mt-2 text-sm tabular-nums text-muted">
                    {done}/{total} ders
                  </p>
                  <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-clay">
                    <div
                      className="h-full rounded-full bg-leaf"
                      style={{ width: `${total ? (done / total) * 100 : 0}%` }}
                    />
                  </div>
                </div>
              </Link>
              <span className="absolute left-0 top-1/2 hidden size-3 -translate-x-[19px] -translate-y-1/2 rounded-full bg-terracotta sm:block" />
              <span className="sr-only">Adım {i + 1}</span>
            </li>
          );
        })}
      </ol>
    </AppShell>
  );
}

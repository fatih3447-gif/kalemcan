import { createFileRoute, Link, Navigate } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { LeafMark } from "@/components/leaf-mark";
import { islandById, lessonsForIsland, type IslandId } from "@/lib/curriculum";
import { useProgress } from "@/lib/progress-store";

export const Route = createFileRoute("/ada/$islandId")({ component: IslandPage });

function IslandPage() {
  const { islandId } = Route.useParams();
  const island = islandById(islandId);
  const stars = useProgress((s) => s.stars);
  if (!island) return <Navigate to="/harita" />;
  const list = lessonsForIsland(island.id as IslandId);

  return (
    <AppShell title={island.title} backTo="/harita">
      <img
        src={island.image}
        alt=""
        className="h-40 w-full rounded-2xl object-cover shadow-border"
      />
      <p className="mt-4 text-ink-soft">{island.subtitle}</p>
      <p className="mt-1 text-sm text-muted">{island.meb}</p>
      <ul className="mt-6 space-y-3">
        {list.map((lesson, i) => {
          const score = stars[lesson.id] ?? 0;
          return (
            <li key={lesson.id}>
              <Link
                to="/ders/$lessonId"
                params={{ lessonId: lesson.id }}
                className="flex items-center gap-4 rounded-2xl bg-page p-4 shadow-border"
              >
                <span className="flex size-12 items-center justify-center rounded-lg bg-clay font-display text-xl">
                  {i + 1}
                </span>
                <div className="min-w-0 flex-1">
                  <h2 className="font-display text-lg">{lesson.title}</h2>
                  <p className="text-sm text-muted">{lesson.subtitle}</p>
                </div>
                <div className="flex gap-0.5 text-leaf">
                  {Array.from({ length: 3 }).map((_, n) => (
                    <LeafMark
                      key={n}
                      className={n < score ? "size-4" : "size-4 opacity-25"}
                    />
                  ))}
                </div>
              </Link>
            </li>
          );
        })}
      </ul>
    </AppShell>
  );
}

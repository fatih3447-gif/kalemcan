import { createFileRoute, Navigate } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import type { Grade } from "@/lib/curriculum";
import { useProgress } from "@/lib/progress-store";
import { speak } from "@/lib/speech";
import { useState } from "react";

export const Route = createFileRoute("/")({ component: Home });

const grades: { id: Grade; label: string; hint: string }[] = [
  { id: 1, label: "1. sınıf", hint: "Harf ve hece" },
  { id: 2, label: "2. sınıf", hint: "Cümle ve kelime" },
  { id: 3, label: "3. sınıf", hint: "Hikaye" },
  { id: 4, label: "4. sınıf", hint: "Kompozisyon" },
];

function Home() {
  const onboarded = useProgress((s) => s.onboarded);
  const onboard = useProgress((s) => s.onboard);
  const addListen = useProgress((s) => s.addListen);
  const [name, setName] = useState("");
  const [grade, setGrade] = useState<Grade>(1);

  if (onboarded) return <Navigate to="/harita" />;

  return (
    <div className="paper-sheet min-h-dvh px-4 py-10">
      <div className="mx-auto flex w-full max-w-lg flex-col gap-6">
        <div className="stagger-in text-center">
          <img
            src="/art/mascot.jpg"
            alt="Kalemcan, yaprak şapkalı kalem"
            className="mx-auto size-40 rounded-2xl object-cover shadow-border"
          />
          <h1 className="mt-5 font-display text-4xl">Merhaba, ben Kalemcan</h1>
          <p className="mt-3 text-lg text-ink-soft">
            MEB’e uygun, oyun gibi bir yazı bahçesi. Harften kompozisyona, birlikte yazalım.
          </p>
          <div className="mt-4 flex justify-center">
            <Button
              variant="paper"
              onClick={() => {
                speak("Merhaba, ben Kalemcan. Birlikte yazmayı öğreneceğiz.");
                addListen();
              }}
            >
              Kalemcan’ı dinle
            </Button>
          </div>
        </div>

        <label className="block">
          <span className="mb-2 block font-display text-lg">Adın ne?</span>
          <Input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Adını yaz"
            maxLength={24}
            autoComplete="nickname"
          />
        </label>

        <div>
          <p className="mb-2 font-display text-lg">Kaçıncı sınıfsın?</p>
          <div className="grid grid-cols-2 gap-3">
            {grades.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setGrade(item.id)}
                className={
                  grade === item.id
                    ? "rounded-xl bg-terracotta px-4 py-4 text-left text-page shadow-border"
                    : "rounded-xl bg-page px-4 py-4 text-left shadow-border"
                }
              >
                <span className="block font-display text-xl">{item.label}</span>
                <span className={grade === item.id ? "text-sm text-page/80" : "text-sm text-muted"}>
                  {item.hint}
                </span>
              </button>
            ))}
          </div>
        </div>

        <Button size="lg" onClick={() => onboard(name, grade)}>
          Bahçeye gir
        </Button>
        <p className="text-center text-sm text-muted">
          1–4. sınıf Türkçe yazma kazanımları: ses, hece, cümle, hikaye, kompozisyon.
        </p>
      </div>
    </div>
  );
}

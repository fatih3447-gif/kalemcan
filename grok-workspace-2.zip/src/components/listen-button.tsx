import { Volume2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useProgress } from "@/lib/progress-store";
import { speak } from "@/lib/speech";

export function ListenButton({ text, label = "Dinle" }: { text: string; label?: string }) {
  const addListen = useProgress((s) => s.addListen);
  return (
    <Button
      type="button"
      variant="paper"
      size="sm"
      onClick={() => {
        const ok = speak(text);
        if (ok) addListen();
      }}
    >
      <Volume2 className="size-4" />
      {label}
    </Button>
  );
}

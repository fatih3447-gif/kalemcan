import { useMemo, useState } from "react";
import { BookMarked, LoaderCircle } from "lucide-react";
import { toast } from "sonner";
import { LeafMark } from "@/components/leaf-mark";
import { ListenButton } from "@/components/listen-button";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { reviewWriting } from "@/lib/ai-review";
import {
  kindLabels,
  writingPrompts,
  type Grade,
  type WritingPrompt,
} from "@/lib/curriculum";
import { useProgress } from "@/lib/progress-store";
import { cn, wordCount } from "@/lib/utils";

function joinScaffold(parts: string[]) {
  return parts.map((part) => part.trim()).filter(Boolean).join("\n\n");
}

function localTips(text: string, minWords: number): string[] {
  const tips: string[] = [];
  const folded = text.trim();
  if (wordCount(folded) < minWords) {
    tips.push(`Biraz daha yaz: en az ${minWords} kelime olsun.`);
  }
  if (folded && folded[0] !== folded[0]?.toLocaleUpperCase("tr-TR")) {
    tips.push("Cümleye büyük harfle başla.");
  }
  if (folded && !/[.!?…]$/.test(folded)) {
    tips.push("Cümleyi nokta, soru veya ünlem ile bitir.");
  }
  if (!tips.length) {
    tips.push("Bir örnek veya duygu cümlesi ekleyerek yazını daha canlı yapabilirsin.");
  }
  return tips.slice(0, 2);
}

export function WriterStudio() {
  const grade = useProgress((s) => s.grade) as Grade;
  const saveWriting = useProgress((s) => s.saveWriting);
  const updateWritingFeedback = useProgress((s) => s.updateWritingFeedback);
  const bumpReview = useProgress((s) => s.bumpReview);
  const writings = useProgress((s) => s.writings);
  const [tab, setTab] = useState<"yeni" | "defter">("yeni");
  const prompts = useMemo(
    () => writingPrompts.filter((prompt) => prompt.grades.includes(grade) || grade >= 3),
    [grade],
  );
  const [selectedId, setSelectedId] = useState(prompts[0]?.id ?? writingPrompts[0].id);
  const prompt = writingPrompts.find((item) => item.id === selectedId) ?? writingPrompts[0];
  const [parts, setParts] = useState<string[]>(() => prompt.scaffold.map(() => ""));
  const [reviewing, setReviewing] = useState(false);
  const [lastFeedback, setLastFeedback] = useState<{
    praise: string;
    tips: string[];
    stars: number;
    nextStep?: string;
  } | null>(null);

  function switchPrompt(next: WritingPrompt) {
    setSelectedId(next.id);
    setParts(next.scaffold.map(() => ""));
    setLastFeedback(null);
  }

  const body = joinScaffold(parts);
  const minWords = grade <= 2 ? 12 : 28;

  async function onSave(withTeacher: boolean) {
    if (wordCount(body) < 4) {
      toast("Birkaç cümle daha yaz, sonra kaydedelim.");
      return;
    }
    const id = saveWriting({
      title: prompt.title,
      body,
      kind: prompt.kind,
    });
    toast("Defterine kaydedildi.");

    if (!withTeacher) return;
    if (!bumpReview()) {
      toast("Öğretmen bugün çok yoruldu. Yarın yeniden bakabilir.");
      return;
    }
    setReviewing(true);
    try {
      const result = await reviewWriting({
        data: {
          title: prompt.title,
          text: body.slice(0, 4000),
          grade,
          kind: prompt.kind,
        },
      });
      if (result.ok) {
        updateWritingFeedback(id, result);
        setLastFeedback(result);
        toast("Öğretmen notunu bıraktı.");
      } else {
        const tips = localTips(body, minWords);
        const fallback = {
          praise: "Emek verdiğin her cümle değerli. Yazmaya devam!",
          tips,
          stars: wordCount(body) >= minWords ? 2 : 1,
          nextStep: "Yarına bir cümle daha ekle.",
        };
        updateWritingFeedback(id, fallback);
        setLastFeedback(fallback);
        toast(result.error);
      }
    } catch {
      toast("Öğretmen şu anda ulaşılamadı.");
    } finally {
      setReviewing(false);
    }
  }

  return (
    <div>
      <div className="mb-5 grid grid-cols-2 rounded-xl bg-clay p-1">
        <button
          type="button"
          className={cn(
            "h-11 rounded-lg font-display",
            tab === "yeni" ? "bg-page text-ink shadow-border" : "text-ink-soft",
          )}
          onClick={() => setTab("yeni")}
        >
          Yeni yazı
        </button>
        <button
          type="button"
          className={cn(
            "h-11 rounded-lg font-display",
            tab === "defter" ? "bg-page text-ink shadow-border" : "text-ink-soft",
          )}
          onClick={() => setTab("defter")}
        >
          Defterim
        </button>
      </div>

      {tab === "yeni" ? (
        <div className="space-y-5">
          <div className="flex gap-2 overflow-x-auto pb-1">
            {prompts.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => switchPrompt(item)}
                className={cn(
                  "shrink-0 rounded-lg px-3 py-2 text-sm shadow-border",
                  item.id === prompt.id ? "bg-terracotta text-page" : "bg-page text-ink-soft",
                )}
              >
                {item.title}
              </button>
            ))}
          </div>

          <section className="rounded-2xl bg-page p-5 shadow-border">
            <p className="text-sm font-medium text-leaf">{kindLabels[prompt.kind]}</p>
            <h2 className="mt-1 font-display text-2xl">{prompt.title}</h2>
            <p className="mt-1 text-ink-soft">{prompt.blurb}</p>
            <p className="mt-2 text-sm text-muted">
              MEB: giriş–gelişme–sonuç, konu ve ana fikir.
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              {prompt.starters.map((starter) => (
                <button
                  key={starter}
                  type="button"
                  className="rounded-md bg-leaf-soft px-3 py-2 text-sm text-leaf"
                  onClick={() => {
                    const next = [...parts];
                    next[0] = `${next[0] ? `${next[0]} ` : ""}${starter} `;
                    setParts(next);
                  }}
                >
                  {starter}…
                </button>
              ))}
            </div>
            <div className="mt-4 space-y-4">
              {prompt.scaffold.map((box, i) => (
                <label key={box.title} className="block">
                  <span className="mb-1 block font-display text-lg">{box.title}</span>
                  <Textarea
                    className="paper-ruled min-h-28"
                    placeholder={box.placeholder}
                    value={parts[i] ?? ""}
                    onChange={(e) => {
                      const next = [...parts];
                      next[i] = e.target.value;
                      setParts(next);
                    }}
                  />
                </label>
              ))}
            </div>
            <p className="mt-3 text-sm text-muted tabular-nums">
              {wordCount(body)} kelime
            </p>
            <div className="sticky bottom-20 z-10 mt-4 flex flex-col gap-3 rounded-xl bg-page/95 p-3 shadow-border sm:flex-row sm:flex-wrap">
              <ListenButton text={body || prompt.title} label="Sesli oku" />
              <Button variant="paper" onClick={() => onSave(false)}>
                <BookMarked className="size-4" />
                Deftere koy
              </Button>
              <Button onClick={() => onSave(true)} disabled={reviewing}>
                {reviewing ? (
                  <LoaderCircle className="size-4 animate-spin" />
                ) : (
                  <LeafMark className="size-4" />
                )}
                Öğretmene göster
              </Button>
            </div>
          </section>

          {lastFeedback && (
            <section className="rounded-2xl bg-leaf-soft p-5">
              <div className="flex gap-1 text-leaf">
                {Array.from({ length: lastFeedback.stars }).map((_, i) => (
                  <LeafMark key={i} />
                ))}
              </div>
              <p className="mt-2 font-display text-xl">{lastFeedback.praise}</p>
              <ul className="mt-3 list-disc space-y-1 pl-5 text-ink-soft">
                {lastFeedback.tips.map((tip) => (
                  <li key={tip}>{tip}</li>
                ))}
              </ul>
              {lastFeedback.nextStep && (
                <p className="mt-3 text-sm text-leaf">{lastFeedback.nextStep}</p>
              )}
            </section>
          )}
        </div>
      ) : (
        <div className="space-y-3">
          {writings.length === 0 ? (
            <div className="rounded-2xl bg-page p-6 text-center shadow-border">
              <p className="font-display text-xl">Defterin henüz boş</p>
              <p className="mt-2 text-ink-soft">İlk yazını yaz, buraya düşsün.</p>
            </div>
          ) : (
            writings.map((entry) => (
              <article key={entry.id} className="rounded-2xl bg-page p-5 shadow-border">
                <p className="text-sm text-muted">
                  {kindLabels[(entry.kind as WritingPrompt["kind"])] ?? entry.kind}
                </p>
                <h3 className="font-display text-xl">{entry.title}</h3>
                <p className="mt-2 whitespace-pre-wrap text-ink-soft">{entry.body}</p>
                {entry.feedback && (
                  <p className="mt-3 text-sm text-leaf">{entry.feedback.praise}</p>
                )}
              </article>
            ))
          )}
        </div>
      )}
    </div>
  );
}

import { useMemo, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Check, RotateCcw, Sparkles } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { LeafMark } from "@/components/leaf-mark";
import { ListenButton } from "@/components/listen-button";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import type { Lesson, Question } from "@/lib/curriculum";
import { useProgress } from "@/lib/progress-store";
import { playComplete, playCorrect, playWrong } from "@/lib/sounds";
import { cn, foldTr, shuffle, wordCount } from "@/lib/utils";

function isCorrect(question: Question, answer: string, ordered: string[]) {
  if (question.type === "choice") return answer === question.correctId;
  if (question.type === "spell") return foldTr(answer) === foldTr(question.answer);
  if (question.type === "order") {
    return (
      ordered.length === question.correct.length &&
      ordered.every((item, i) => item === question.correct[i])
    );
  }
  return wordCount(answer) >= question.minWords;
}

export function LessonEngine({ lesson }: { lesson: Lesson }) {
  const navigate = useNavigate();
  const completeLesson = useProgress((s) => s.completeLesson);
  const [index, setIndex] = useState(0);
  const [choice, setChoice] = useState<string | null>(null);
  const [typed, setTyped] = useState("");
  const [picked, setPicked] = useState<string[]>([]);
  const [pool, setPool] = useState<string[]>([]);
  const [status, setStatus] = useState<"idle" | "ok" | "bad">("idle");
  const [firstTries, setFirstTries] = useState(0);
  const [attempts, setAttempts] = useState(0);
  const [done, setDone] = useState(false);
  const question = lesson.questions[index];

  const seededPool = useMemo(() => {
    if (!question || question.type !== "order") return [];
    let tiles = shuffle(question.tiles);
    if (tiles.join("|") === question.correct.join("|")) tiles = shuffle(tiles);
    return tiles;
  }, [question]);

  if (!question) return null;

  const startPool = pool.length || picked.length ? pool : seededPool;
  const progress = ((index + (done ? 1 : 0)) / lesson.questions.length) * 100;
  const stars = firstTries === lesson.questions.length ? 3 : firstTries >= Math.ceil(lesson.questions.length * 0.7) ? 2 : 1;
  const leaves = stars + (stars === 3 ? 2 : 0);

  function resetQuestionExtras() {
    setChoice(null);
    setTyped("");
    setPicked([]);
    setPool([]);
    setStatus("idle");
    setAttempts(0);
  }

  function check() {
    if (!question) return;
    const ok = isCorrect(question, choice ?? typed, picked);
    if (ok) {
      playCorrect();
      setStatus("ok");
      if (attempts === 0) setFirstTries((n) => n + 1);
    } else {
      playWrong();
      setStatus("bad");
      setAttempts((n) => n + 1);
    }
  }

  function next() {
    if (index + 1 >= lesson.questions.length) {
      playComplete();
      completeLesson(lesson.id, stars, leaves);
      setDone(true);
      return;
    }
    setIndex((n) => n + 1);
    resetQuestionExtras();
  }

  return (
    <AppShell title={lesson.title} backTo={`/ada/${lesson.islandId}`}>
      <div className="mb-4 h-2 overflow-hidden rounded-full bg-clay">
        <div
          className="h-full rounded-full bg-leaf transition-[width] duration-300 ease-out"
          style={{ width: `${done ? 100 : progress}%` }}
        />
      </div>

      {done ? (
        <div className="stagger-in paper-sheet rounded-2xl p-6 shadow-border">
          <img src="/art/mascot.jpg" alt="" className="mx-auto size-28 rounded-xl object-cover" />
          <h2 className="mt-4 text-center font-display text-3xl">Harika iş!</h2>
          <p className="mt-2 text-center text-ink-soft">{lesson.subtitle} tamamlandı.</p>
          <div className="mt-5 flex justify-center gap-2">
            {Array.from({ length: stars }).map((_, i) => (
              <span key={i} className="leaf-pop text-leaf" style={{ animationDelay: `${i * 80}ms` }}>
                <LeafMark className="size-8" />
              </span>
            ))}
          </div>
          <p className="mt-3 text-center font-display text-lg text-leaf">+{leaves} yaprak</p>
          <div className="mt-6 grid gap-3">
            <Button size="lg" onClick={() => navigate({ to: `/ada/${lesson.islandId}` })}>
              Adaya dön
            </Button>
            <Button
              size="lg"
              variant="paper"
              onClick={() => navigate({ to: "/yaz" })}
            >
              Yazı defterine geç
            </Button>
          </div>
        </div>
      ) : (
        <div className={cn("rounded-2xl bg-page p-5 shadow-border", status === "bad" && "shake-x")}>
          <p className="text-sm font-medium uppercase tracking-wide text-muted">
            {index + 1} / {lesson.questions.length}
          </p>
          <h2 className="mt-2 font-display text-2xl">{question.prompt}</h2>
          <div className="mt-3">
            <ListenButton text={question.speak ?? question.prompt} />
          </div>

          {question.type === "choice" && (
            <div className="mt-5 grid gap-3">
              {question.options.map((option) => {
                const selected = choice === option.id;
                const reveal = status === "ok" && option.id === question.correctId;
                return (
                  <button
                    key={option.id}
                    type="button"
                    onClick={() => {
                      if (status === "ok") return;
                      setChoice(option.id);
                      setStatus("idle");
                    }}
                    className={cn(
                      "min-h-14 rounded-xl px-4 py-3 text-left font-display text-xl shadow-border transition-[transform,background-color,color] duration-150 active:scale-[0.96]",
                      reveal
                        ? "bg-leaf-soft text-leaf"
                        : selected
                          ? "bg-clay text-ink"
                          : "bg-paper text-ink",
                    )}
                  >
                    {option.label}
                  </button>
                );
              })}
            </div>
          )}

          {question.type === "spell" && (
            <div className="mt-5">
              <Input
                value={typed}
                onChange={(e) => {
                  setTyped(e.target.value);
                  setStatus("idle");
                }}
                placeholder="Buraya yaz"
                autoCapitalize="none"
                autoCorrect="off"
                spellCheck={false}
              />
            </div>
          )}

          {question.type === "order" && (
            <div className="mt-5 space-y-4">
              <div className="flex min-h-16 flex-wrap gap-2 rounded-xl bg-sun/70 p-3">
                {picked.length === 0 && (
                  <span className="text-sm text-muted">Sıraya koymak için taşlara dokun</span>
                )}
                {picked.map((tile, i) => (
                  <button
                    key={`${tile}-${i}`}
                    type="button"
                    className="rounded-md bg-page px-3 py-2 font-display text-lg shadow-border"
                    onClick={() => {
                      if (status === "ok") return;
                      setPicked(picked.filter((_, idx) => idx !== i));
                      setPool([...startPool, tile]);
                      setStatus("idle");
                    }}
                  >
                    {tile}
                  </button>
                ))}
              </div>
              <div className="flex flex-wrap gap-2">
                {startPool.map((tile, i) => (
                  <button
                    key={`${tile}-p-${i}`}
                    type="button"
                    className="rounded-md bg-clay px-3 py-2 font-display text-lg"
                    onClick={() => {
                      if (status === "ok") return;
                      setPool(startPool.filter((_, idx) => idx !== i));
                      setPicked([...picked, tile]);
                      setStatus("idle");
                    }}
                  >
                    {tile}
                  </button>
                ))}
              </div>
            </div>
          )}

          {question.type === "write" && (
            <div className="mt-5 space-y-3">
              {question.starters && (
                <div className="flex flex-wrap gap-2">
                  {question.starters.map((starter) => (
                    <button
                      key={starter}
                      type="button"
                      className="rounded-md bg-leaf-soft px-3 py-2 text-sm text-leaf"
                      onClick={() => setTyped((prev) => `${prev}${prev ? " " : ""}${starter} `)}
                    >
                      {starter}
                    </button>
                  ))}
                </div>
              )}
              {question.scaffold ? (
                <div className="space-y-3">
                  {question.scaffold.map((box, i) => (
                    <label key={box.title} className="block">
                      <span className="mb-1 block text-sm font-medium text-ink-soft">{box.title}</span>
                      <Textarea
                        className="paper-ruled min-h-28"
                        placeholder={box.placeholder}
                        value={typed.split("\n\n")[i] ?? ""}
                        onChange={(e) => {
                          const parts = typed.split("\n\n");
                          while (parts.length < question.scaffold!.length) parts.push("");
                          parts[i] = e.target.value;
                          setTyped(parts.join("\n\n"));
                          setStatus("idle");
                        }}
                      />
                    </label>
                  ))}
                </div>
              ) : (
                <Textarea
                  className="paper-ruled min-h-44"
                  value={typed}
                  placeholder="Yazmaya başla…"
                  onChange={(e) => {
                    setTyped(e.target.value);
                    setStatus("idle");
                  }}
                />
              )}
              <p className="text-sm text-muted tabular-nums">
                {wordCount(typed)} kelime · en az {question.minWords}
              </p>
            </div>
          )}

          {status === "ok" && (
            <p className="mt-4 flex items-center gap-2 font-display text-lg text-leaf">
              <Check className="size-5" /> Bravo, doğru!
            </p>
          )}
          {status === "bad" && (
            <p className="mt-4 text-terracotta">
              {question.hint ?? "Bir daha dene, neredeyse oldu."}
            </p>
          )}

          <div className="mt-6 flex flex-wrap gap-3">
            {status === "ok" ? (
              <Button size="lg" className="flex-1" onClick={next}>
                {index + 1 >= lesson.questions.length ? "Bitir" : "Sonraki"}
                <Sparkles className="size-4" />
              </Button>
            ) : (
              <Button
                size="lg"
                className="flex-1"
                onClick={check}
                disabled={
                  (question.type === "choice" && !choice) ||
                  (question.type === "spell" && !typed.trim()) ||
                  (question.type === "order" && picked.length === 0) ||
                  (question.type === "write" && !typed.trim())
                }
              >
                Kontrol et
              </Button>
            )}
            {status === "bad" && (
              <Button
                size="lg"
                variant="ghost"
                onClick={() => {
                  resetQuestionExtras();
                }}
              >
                <RotateCcw className="size-4" />
                Sıfırla
              </Button>
            )}
          </div>
        </div>
      )}
    </AppShell>
  );
}

import { Link, useRouter, useRouterState } from "@tanstack/react-router";
import { ChevronLeft, Map, PencilLine, Trophy } from "lucide-react";
import { LeafMark } from "@/components/leaf-mark";
import { useProgress } from "@/lib/progress-store";
import { cn } from "@/lib/utils";

const tabs = [
  { to: "/harita", label: "Bahçe", icon: Map },
  { to: "/yaz", label: "Yaz", icon: PencilLine },
  { to: "/rozetler", label: "Rozetler", icon: Trophy },
] as const;

export function AppShell({
  children,
  title,
  backTo,
}: {
  children: React.ReactNode;
  title?: string;
  backTo?: string;
}) {
  const router = useRouter();
  const name = useProgress((s) => s.name);
  const leaves = useProgress((s) => s.leaves);
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <div className="paper-sheet min-h-dvh">
      <header className="sticky top-0 z-20 border-b border-line bg-page/90 px-4 py-3 backdrop-blur-sm">
        <div className="mx-auto flex max-w-3xl items-center gap-3">
          {backTo ? (
            <button
              type="button"
              onClick={() => router.history.push(backTo)}
              className="inline-flex size-11 items-center justify-center rounded-lg text-ink-soft shadow-border"
              aria-label="Geri"
            >
              <ChevronLeft className="size-5" />
            </button>
          ) : (
            <Link to="/harita" className="flex min-w-0 items-center gap-2">
              <img
                src="/art/mascot.jpg"
                alt=""
                className="size-11 rounded-lg object-cover"
              />
              <div className="min-w-0">
                <p className="font-display text-lg leading-none text-ink">Kalemcan</p>
                <p className="truncate text-sm text-muted">{name || "Minik yazar"}</p>
              </div>
            </Link>
          )}
          {title ? (
            <h1 className="min-w-0 flex-1 truncate font-display text-xl">{title}</h1>
          ) : (
            <div className="flex-1" />
          )}
          <div className="inline-flex h-11 items-center gap-1.5 rounded-lg bg-leaf-soft px-3 text-leaf tabular-nums">
            <LeafMark className="size-4" />
            <span className="font-display font-medium">{leaves}</span>
          </div>
        </div>
      </header>
      <main className="mx-auto w-full max-w-3xl px-4 pb-32 pt-5">{children}</main>
      <nav className="fixed inset-x-0 bottom-0 z-20 border-t border-line bg-page/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-sm">
        <div className="mx-auto grid max-w-3xl grid-cols-3">
          {tabs.map((tab) => {
            const active = pathname === tab.to || pathname.startsWith(`${tab.to}/`);
            const Icon = tab.icon;
            return (
              <Link
                key={tab.to}
                to={tab.to}
                className={cn(
                  "flex min-h-16 flex-col items-center justify-center gap-1 text-sm",
                  active ? "text-terracotta" : "text-muted",
                )}
              >
                <Icon className="size-5" />
                {tab.label}
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}

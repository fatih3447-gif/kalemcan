import { cva, type VariantProps } from "class-variance-authority";
import type { ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 font-display font-medium transition-[transform,background-color,box-shadow,opacity] duration-150 ease-out select-none disabled:pointer-events-none disabled:opacity-45 active:not-disabled:scale-[0.96] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-terracotta",
  {
    variants: {
      variant: {
        primary:
          "bg-terracotta text-page shadow-border hover:bg-terracotta-dark",
        leaf: "bg-leaf text-page shadow-border hover:opacity-90",
        paper:
          "bg-page text-ink shadow-border hover:shadow-border-hover",
        ghost: "bg-transparent text-ink-soft hover:bg-clay/60",
      },
      size: {
        md: "h-12 rounded-lg px-5 text-base",
        lg: "h-14 rounded-xl px-6 text-lg",
        sm: "h-10 rounded-md px-4 text-sm",
        icon: "size-12 rounded-lg",
      },
    },
    defaultVariants: { variant: "primary", size: "md" },
  },
);

export function Button({
  className,
  variant,
  size,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & VariantProps<typeof buttonVariants>) {
  return (
    <button className={cn(buttonVariants({ variant, size }), className)} {...props} />
  );
}

import { cn } from "@/lib/utils";

export function LeafMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={cn("size-5", className)} aria-hidden>
      <path
        fill="currentColor"
        d="M19.6 4.4c-4.2-.2-9.2 1.6-12 5.3-2.6 3.4-3 7.6-1.4 10.1 2.5 2.4 6.8 1.8 10.1-1.4 3.7-2.8 5.5-7.8 5.3-12-.7 2.2-2.3 4-4.4 4.8 1.4-3.1.7-6.3-1.6-8.2 2.2.4 4 1.6 5 3.4.2-1 .2-1.4-1-2z"
      />
      <path
        fill="none"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinecap="round"
        d="M8 20c3.4-3.6 6-8.4 7.4-14"
        opacity=".55"
      />
    </svg>
  );
}
